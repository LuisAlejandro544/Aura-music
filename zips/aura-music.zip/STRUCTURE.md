# Estructura del Proyecto Aura Music 🎧

Este documento detalla la arquitectura de software, organización de módulos, responsabilidades y componentes de **Aura Music**.

---

## 🏛️ Visión General de Arquitectura (MVVM + Clean Architecture)

El proyecto sigue una arquitectura reactiva y desacoplada organizada en capas:

1. **Capa Nativa (C++20 / NDK)**: Motores de procesamiento de audio digital DSP en tiempo real (Ecualizador paramétrico de 10 bandas IIR, Audio 8D/16D Multi-Órbita, Clarificador de Voces Mid-Side HD, Reverb Schroeder/Moorer y Crossfeed Chu Moy) + binarios nativos optimizados de FFmpeg y QuickJS/CPython.
2. **Capa de Datos & Almacenamiento (Data & Storage)**:
   - Base de datos SQLite reactiva con **Room**.
   - Acceso al almacenamiento estructurado en `Android/data/com.aistudio.musicplayer.aurasound/files/` (Debug) y `Android/data/com.auramusic.beta/files/` (APK Beta `Aura Beta` • Codename `Nebula`) con subcarpetas (`songs/`, `images/`, `lyrics/`, `metadata/`, `videos/`), además de **Carpeta Pública / Personalizada del Usuario (`UserPublicMediaExporter` & `UserPublicFolderCard`)** mediante SAF (`OpenDocumentTree`) con subcarpeta `Videos/` (y preparada para `Images/`) para exportar vídeos descargados con su audio completo.
   - Motores de importación, sincronización de letras LRCLIB, extracción FFmpeg, descarga resiliente con separación de `audioHeaders`/`videoHeaders` por perfil `c=` y cascada anti-HTTP 403 de 5 niveles (`ChunkedStreamDownloader` -> `InnerTubeClient` -> `InvidiousStreamResolver` -> `HeadlessWebViewExtractor` -> `YtDlpNativeEngine.downloadStreamDirectToFile` con actualización OTA activa en Debug y Beta) y actualizador automático de versiones APK (`AppReleaseUpdater` con comparador semántico de tags dinámicos `-beta`, selección por arquitectura móvil y verificación SHA-256).
3. **Capa de Control & Reproducción (Playback Layer)**:
   - `AuraAudioPlayer` con ExoPlayer/Media3, modularizado con controladores especializados (`PlayerQueueController`, `AudioFadeController`, `ABLoopController`, `MediaSessionBridge`).
   - `NativeAudioEngine` conectando buffers de audio PCM en C++20 vía JNI.
4. **Capa de Lógica de Negocio & Estado (ViewModel Layer)**:
   - `MusicViewModel` modularizado y ultra liviano, orquestado por coordinadores y delegados especializados:
     - `AudioEffectsCoordinator`: Ecualizador C++20 de 10 bandas, Audio 8D/16D, Clarificador de Voces HD, Reverb, Normalizador EBU R128, Automix DJ y Sleep Timer.
     - `NavigationCoordinator`: Rutas de navegación, temas visuales, modo de diseño del reproductor y selección de colecciones.
     - `TrackLibraryCoordinator`: CRUD de pistas y playlists, importación SAF de archivos/carpetas, Video a Música y descargas en segundo plano con `AuraDownloadService`.
     - `LyricsCoordinator`: Gestión de letras locales y remotas LRCLIB.
     - `IncomingMediaCoordinator`: Recepción "Abrir con..." y "Compartir con...".
      - `HeadphoneSettingsCoordinator`: Detección acústica de auriculares, modo Bit-Perfect/AAudio, guardado y balance estéreo.
      - `MixtapeCoordinator`: Fusión continua de canciones en FFmpeg y capítulos reactivos en tiempo real.
      - `StreamingModeCoordinator`: Orquestador del Modo Streaming tri-plataforma (YT Music, YouTube & SoundCloud), caché inteligente y Radio Similar.
      - `PlaylistImportCoordinator`: Orquestador del Importador Universal de Playlists de Spotify y YouTube Music / YouTube (Modo Streaming Instantáneo o Descarga Offline en 2do plano).
5. **Capa de Presentación (UI con Jetpack Compose & Material 3)**:
   - Pantallas modulares (`HomeScreen`, `LibraryScreen`, `NowPlayingScreen`, `SettingsScreen`, `ImportMusicScreen`, `OnboardingScreen`, `PlaylistDetailScreen`).
   - Host global modularizado (`AuraMusicAppContent`, `GlobalDialogsHost`).
   - Componentes modulares reutilizables organizados en submódulos temáticos.

---

## 📂 Árbol de Directorios y Módulos

```text
zips/                                           # Carpeta receptora de paquetes .zip para sincronización automática de ramas
├── README.md                                   # Guía rápida de uso desde dispositivos móviles
└── .gitkeep                                    # Mantiene la carpeta visible tras auto-eliminar los .zip procesados

app/
├── build.gradle.kts                            # Configuración Gradle, NDK C++20 y tarea provisionNativeDeps
├── proguard-rules.pro                          # Reglas de optimización R8 Full Mode y ofuscación Beta/Release
└── src/
    ├── beta/                                   # Recursos y Manifiesto exclusivos del canal APK Beta (Aura Beta • Nebula)
    │   ├── AndroidManifest.xml                 # Remueve DebugMonitorActivity en compilaciones Beta
    │   └── res/values/strings.xml              # Nombre de app "Aura Beta"
    │
    ├── main/
    │   ├── AndroidManifest.xml                 # Manifiesto principal, servicios Media3/Descargas, Widgets y Android Auto
    │   ├── cpp/                                # Núcleo C++20 Nativo DSP & Launchers PIE (QuickJS C99 puro compilado en Gradle)
    │   │   ├── CMakeLists.txt                  # Configuración CMake C17 / ISO C++20 con optimización LTO y AAudio
    │   │   ├── auramusic_dsp.h                 # Fachada pública del motor DSP de 64 bits
    │   │   ├── auramusic_dsp.cpp               # Implementación JNI thread-safe (std::mutex) y ruteo de buffers std::span
    │   │   ├── dsp_filters.h                   # Filtros Biquad IIR, EQ 10 bandas, Vocal Clarity Mid-Side, EBU R128 y DJ Automix
    │   │   ├── dsp_spatial.h                   # Paneo 8D Clásico y Audio Espacial 16D Multi-Órbita Binaural
    │   │   ├── dsp_crossfeed.h                 # Filtro Crossfeed acústico binaural Chu Moy / Bauer para auriculares
    │   │   ├── dsp_reverb.h                    # Reverb digital Schroeder/Moorer en C++20 con líneas de retardo libres de bloqueo
    │   │   ├── dsp_bitperfect.h                # Motor Bit-Perfect 1:1 y salida Google AAudio Ultra-Baja Latencia
    │   │   ├── native_ffmpeg_launcher.c        # Lanzador PIE POSIX con validación stat() y dlopen hacia FFmpeg nativo
    │   │   ├── native_python_launcher.c        # Lanzador PIE POSIX embebedor de CPython 3.11 nativo
    │   │   └── aura_ytdlp_fallback.py          # Script Python de respaldo para extracción directa si falla la red en build
    │   │
    │   └── java/com/example/
    │       ├── AuraApplication.kt              # Inicialización global, ciclo de vida Modo Juego, OTA yt-dlp y limpieza OEM
    │       ├── MainActivity.kt                 # Actividad principal modularizada (< 140 líneas), permisos e Intents
    │       │
    │       ├── core/                           # Núcleo de Datos, Modelos de Dominio y Motor de Reproducción
    │       │   ├── data/
    │       │   │   ├── local/                  # Capa de Persistencia Local (Room SQLite)
    │       │   │   │   ├── AppDatabase.kt      # Base de datos Room con migraciones
    │       │   │   │   ├── dao/
    │       │   │   │   │   ├── TrackDao.kt
    │       │   │   │   │   └── PlaylistDao.kt
    │       │   │   │   └── entity/
    │       │   │   │       ├── TrackEntity.kt
    │       │   │   │       ├── PlaylistEntity.kt
    │       │   │   │       └── PlaylistTrackCrossRef.kt
    │       │   │   │
    │       │   │   ├── repository/             # Repositorios y Operaciones de Datos
    │       │   │   │   ├── MusicRepository.kt  # Fachada principal de repositorio
    │       │   │   │   ├── PlaylistRepository.kt # Gestión de listas y cross-references
    │       │   │   │   └── SafTrackImporter.kt # Importador SAF blindado contra colisiones de extensiones
    │       │   │   │
    │       │   │   ├── storage/                # Almacenamiento Interno y Exportación Pública del Usuario
    │       │   │   │   ├── AppStorageManager.kt # Manejo de disco estructurado en Android/data/.../files/
    │       │   │   │   └── UserPublicMediaExporter.kt # Exportador SAF a carpeta pública del usuario con fusión FFmpeg (.mp4 con audio)
    │       │   │   │
    │       │   │   ├── updater/                # Actualizador Automático de Versiones APK
    │       │   │   │   └── AppReleaseUpdater.kt # Comparador semántico de tags -beta, selector ABI y verificador SHA-256
    │       │   │   │
    │       │   │   ├── importer/               # Motores de Descarga, Conversión y Medios Organizados
    │       │   │   │   ├── IncomingMediaHandler.kt # Triaje seguro de Intents ("Abrir con..." y "Compartir con...")
    │       │   │   │   ├── engines/            # Motores Nativos CLI (FFmpeg, CPython + QuickJS C99 y OTA yt-dlp)
    │       │   │   │   │   ├── FFmpegNativeEngine.kt # Extracción, loops xfade/Boomerang, GOP corto y prevención de Flag Injection
    │       │   │   │   │   ├── YtDlpNativeEngine.kt  # Ejecución nativa CPython + QuickJS C99 puro y CA TLS Android 14+ APEX
    │       │   │   │   │   └── YtDlpAutoUpdater.kt   # Actualizador OTA de yt-dlp con blindaje criptográfico SHA-256
    │       │   │   │   ├── extractors/         # Extractores de Video y Audio Web
    │       │   │   │   │   ├── OnlineVideoAudioImporter.kt # Orquestador de importación web con cascada anti-HTTP 403 de 5 niveles
    │       │   │   │   │   ├── InnerTubeClient.kt          # Cliente directo YouTube InnerTube multi-perfil (<300ms)
    │       │   │   │   │   ├── InvidiousStreamResolver.kt  # Bypass de streams mediante instancias Invidious
    │       │   │   │   │   ├── HeadlessWebViewExtractor.kt # Extractor WebView móvil en sandbox con cascada de portadas
    │       │   │   │   │   └── WebStreamExtractor.kt       # Extractor web universal y detector de subdominios YouTube
    │       │   │   │   ├── audio/              # Procesamiento Acústico, Formatos Especiales y Metadatos
    │       │   │   │   │   ├── AudioMetadataParser.kt      # Extracción de tags ID3, Vorbis y WebP
    │       │   │   │   │   ├── AudioSilenceTrimmer.kt      # Supresión inteligente de silencios al inicio y fin (-42 dB RMS)
    │       │   │   │   │   ├── SpecialAudioFormatDecoder.kt # Decodificador nativo DSD, APE, WavPack, ALAC, AIFF, MPC y Chiptune
    │       │   │   │   │   ├── VideoAudioExtractor.kt      # Conversor Video a Música 3 en 1 (Demuxing directo en ~1s)
    │       │   │   │   │   └── SampleMusicGenerator.kt     # Generador procedural de pistas sintetizadas demo
    │       │   │   │   ├── artwork/            # Procesamiento de Portadas WebP y Arte Procedural
    │       │   │   │   │   ├── MediaAssetProcessor.kt        # Compresión WebP Lossless, recorte letterbox 4:3 y Video Canvas
    │       │   │   │   │   └── ProceduralArtworkGenerator.kt # Generador matemático de portadas procedurales
    │       │   │   │   ├── lyrics/             # Motor de Letras Sincronizadas (.LRC / .TXT)
    │       │   │   │   │   └── LyricsManager.kt # Búsqueda y descarga de letras sincronizadas LRCLIB con versión oficial #1
    │       │   │   │   ├── mixtape/            # Fusión Continua y Auto-Remix / Mashup de 2 Canciones Locales
    │       │   │   │   │   ├── MixtapeEngine.kt        # Fusión FFmpeg acrossfade, collage WebP y capítulos reactivos
    │       │   │   │   │   └── SmartAutoRemixEngine.kt # Auto-Remix de 2 pistas (Mashup Voz A + Base B / Remix DJ) y Auto-Match
    │       │   │   │   ├── playlist/           # Importador Universal de Playlists Públicas
    │       │   │   │   │   └── ExternalPlaylistImporter.kt # Extracción de Playlists de Spotify y YouTube Music sin login ni API keys
    │       │   │   │   ├── download/           # Acelerador de Descargas HTTP Range
    │       │   │   │   │   └── ChunkedStreamDownloader.kt # Descarga acelerada HTTP Range multi-bloque con guardia anti-SSRF
    │       │   │   │   └── tiktok/             # Resolución Directa de TikTok
    │       │   │   │       └── TikTokMediaResolver.kt # Extracción libre de audio/video de TikTok sin marcas de agua
    │       │   │   │
    │       │   │   └── streaming/              # Modo Streaming Híbrido Tri-Plataforma (YT Music + YouTube + SoundCloud)
    │       │   │       ├── StreamingApiService.kt           # Búsqueda tri-plataforma, Radio Similar y resolución híbrida
    │       │   │       ├── SoundCloudApiClient.kt           # Cliente modular de SoundCloud (hidratación client_id v2 y streams)
    │       │   │       ├── StreamingCacheManager.kt         # Caché inteligente (50-500 MB, 30 min TTL, LRU) y Pre-descarga No Lineal
    │       │   │       └── StreamingHttpDataSourceConfig.kt # Alineación de cabeceras User-Agent/Origin por perfil firmado c=
    │       │   │
    │       │   ├── model/                      # Modelos de Dominio y Estado
    │       │   │   ├── Track.kt
    │       │   │   ├── Playlist.kt
    │       │   │   ├── StreamingModels.kt      # Modelos de búsqueda streaming, importador de playlists y políticas de red
    │       │   │   ├── WidgetModels.kt         # Modelos de configuración y estado persistido de los 2 Widgets
    │       │   │   ├── AppUpdateModels.kt      # Modelos de estado y metadatos del actualizador APK
    │       │   │   ├── MixtapeModels.kt        # Modelos de capítulos, metadatos de Mixtape y configuración de Auto-Remix
    │       │   │   ├── LyricsState.kt
    │       │   │   ├── LyricSearchResult.kt
    │       │   │   ├── EqualizerConfig.kt
    │       │   │   ├── AudioEffectsConfig.kt
    │       │   │   ├── HeadphoneConfig.kt
    │       │   │   ├── DownloadProgress.kt
    │       │   │   ├── PackageUpdateState.kt
    │       │   │   ├── RepeatMode.kt
    │       │   │   ├── ThemePalette.kt
    │       │   │   ├── AppWallpaperConfig.kt   # Configuración de fondo de pantalla personalizado de galería (WebP/MP4)
    │       │   │   ├── VideoDisplayMode.kt
    │       │   │   └── NowPlayingDesignMode.kt # Modos de diseño del reproductor: Clásico, Cinemático Canvas y Auto
    │       │   │
    │       │   └── playback/                   # Capa de Audio y Reproducción ExoPlayer / Media3
    │       │       ├── AuraAudioPlayer.kt          # Fachada del reproductor de audio y soporte Dual-Deck
    │       │       ├── AuraMediaPlaybackService.kt # MediaSessionService para System Media Controls y Android Auto
    │       │       ├── AuraDownloadService.kt      # Servicio en primer plano para descargas web y lotes de Playlists
    │       │       ├── AudioEffectManager.kt       # Gestión de ecualizador y efectos nativos C++20
    │       │       ├── HeadphoneController.kt      # BroadcastReceiver para audífonos, Becoming Noisy y botones físicos
    │       │       ├── NativeAudioEngine.kt        # Puente JNI hacia el motor DSP en ISO C++20 y AAudio
    │       │       ├── NativeAudioProcessor.kt     # AudioProcessor de ExoPlayer hacia el motor C++20 con Buffer Flushing
    │       │       └── controllers/
    │       │           ├── PlayerQueueController.kt # Gestión de cola contextual y modos de repetición/aleatorio
    │       │           ├── AudioFadeController.kt   # Crossfade Dual-Deck (Equal-Power sin/cos), Smart AutoMix, Fade-In/Out y Sleep Timer
    │       │           ├── ABLoopController.kt      # Bucle de repetición de segmento A-B
    │       │           └── MediaSessionBridge.kt    # Puente de notificación nativa System Media Controls
    │       │
    │       ├── feature/                        # Pantallas Modulares por Funcionalidad (Feature Layer)
    │       │   ├── home/
    │       │   │   └── HomeScreen.kt           # Pantalla de Inicio con acceso rápido, populares y recientes
    │       │   ├── streaming/
    │       │   │   └── StreamingExploreScreen.kt # Pestaña Explorar / Streaming Tri-Plataforma (YT Music, YouTube & SoundCloud)
    │       │   ├── library/
    │       │   │   ├── LibraryScreen.kt        # Pantalla de Biblioteca (Canciones, Favoritos, Playlists, Artistas y Álbumes)
    │       │   │   └── components/
    │       │   │       ├── AlbumAndArtistCards.kt        # Tarjetas de Álbumes y Artistas con apertura de detalle de canciones
    │       │   │       ├── FavoritesPlaylistBannerCard.kt # Banner destacado de la lista sincronizada "Tus Me Gusta"
    │       │   │       ├── LibraryEmptyViews.kt          # Vistas de estado vacío para pestañas de la Biblioteca
    │       │   │       ├── PlaylistDialogs.kt            # Diálogos de creación, edición y adición de pistas a Playlists
    │       │   │       └── PlaylistRowItem.kt            # Fila interactiva de Playlist con collage dinámico 1-4 fotos o WebP
    │       │   ├── nowplaying/
    │       │   │   ├── NowPlayingScreen.kt     # Orquestador del reproductor a pantalla completa (Clásico / Cinemático / Auto)
    │       │   │   └── components/
    │       │   │       ├── FullScreenLyricsScreen.kt       # Modo Karaoke Inmersivo a Pantalla Completa estilo Apple Music Sing
    │       │   │       ├── NowPlayingCinematicLayout.kt    # Diseño Cinemático Canvas (Estilo Spotify) con viñeta reactiva a 1s
    │       │   │       ├── NowPlayingDesignSelectorDialog.kt # Selector modal de modo de diseño del reproductor
    │       │   │       ├── NowPlayingArtworkCard.kt        # Tarjeta de carátula 1:1 y lienzo de video despejado
    │       │   │       ├── NowPlayingLyricsCard.kt         # Tarjeta sincronizada de letras Karaoke 1:1 con auto-scroll
    │       │   │       ├── NowPlayingPlaybackControls.kt   # Controles de transporte y barra continua con selector circular ("bolita")
    │       │   │       ├── NowPlayingQueueSheet.kt         # Hoja modal de cola de reproducción con miniaturas HD
    │       │   │       ├── NowPlayingTopBar.kt             # Barra superior con accesos a especificaciones, Karaoke, diseño y efectos
    │       │   │       ├── NowPlayingBalanceBar.kt         # Barra interactiva de Balance Estéreo Fino L/R
    │       │   │       ├── AudioSpecsDialog.kt             # Ficha técnica de pista, telemetría AAudio y estado Bit-Perfect
    │       │   │       └── VideoDisplayModeDialog.kt       # Selector modal de encuadre de Video Canvas (4 modos)
    │       │   ├── playlist/
    │       │   │   └── PlaylistDetailScreen.kt # Vista detallada de canciones para Playlists, Artistas y Álbumes
    │       │   ├── importmusic/
    │       │   │   └── ImportMusicScreen.kt    # Centro de importación SAF, Video a Música, descargas web y Playlists externas
    │       │   ├── onboarding/
    │       │   │   ├── OnboardingScreen.kt         # Flujo de bienvenida e inducción en 3 etapas
    │       │   │   └── OnboardingStepComponents.kt # Tarjetas modulares de propuesta de valor y disclaimer de almacenamiento
    │       │   └── settings/
    │       │       ├── SettingsScreen.kt       # Orquestador de Ajustes y navegación a sub-menús de pantalla completa
    │       │       └── components/
    │       │           ├── SettingDetailRow.kt            # Fila reutilizable de información clave-valor
    │       │           ├── SettingsSubScreenComponents.kt # Tarjetas navegables y contenedor SettingsSubMenuScreen
    │       │           ├── widgets/                       # Personalización y Vista Previa de los 2 Widgets
    │       │           │   └── WidgetSettingsContent.kt   # Selector Top 4 Canciones/Playlists, color de imagen y vista previa
    │       │           ├── about/                         # Detrás del Proyecto (Creador & Contribuidores)
    │       │           │   └── BehindTheProjectSection.kt # Perfiles de GitHub con caché permanente de avatares en WebP
    │       │           ├── appearance/                    # Ajustes de Apariencia, Streaming, Modo Juego, Fondo y Motores
    │       │           │   ├── AppearanceSettingsTab.kt             # Menú principal de categorías de Ajustes
    │       │           │   ├── AppWallpaperSettingsSection.kt       # Controles de fondo de pantalla de galería (WebP/Video, Opacidad y Blur)
    │       │           │   ├── StreamingCacheAndVideoSettingsCard.kt # Ajustes de caché inteligente (50-500 MB), política de red y Modo Juego
    │       │           │   ├── EnginesAndDiagnosticsSection.kt      # Estado de FFmpeg, QuickJS C99 puro, yt-dlp OTA y Aura Monitor
    │       │           │   └── PlayerDesignSettingsContent.kt       # Pantalla dedicada de selección de Diseño del Reproductor
    │       │           ├── headphones/                    # Ajustes de Auriculares, Acústica DSP, Bit-Perfect y Gestos
    │       │           │   ├── BitPerfectSettingsSection.kt   # Configuración Bit-Perfect 1:1 y Google AAudio Hi-Res
    │       │           │   ├── HeadphoneStatusCard.kt         # Tarjeta de estado de conexión de audífonos en vivo
    │       │           │   ├── HeadphonesAcousticsSection.kt  # Crossfeed Chu Moy y Balance Estéreo Fino L/R
    │       │           │   ├── HeadphonesSecuritySection.kt   # Becoming Noisy Guard, Fade-In y Memoria de Volumen
    │       │           │   ├── HeadphonesGesturesSection.kt   # Mapeo de 1, 2, 3 pulsaciones y mantener presionado
    │       │           │   └── HeadsetButtonActionDialog.kt   # Selector modal de acción para botones de auriculares
    │       │           ├── updater/                       # Actualizador Automático de Versiones APK
    │       │           │   └── AppReleaseUpdateSettingsCard.kt # Tarjeta de consulta y descarga de nuevas versiones APK
    │       │           └── media/                         # Gestión de Medios Almacenados y Carpeta Pública del Usuario
    │       │               ├── StoredMediaSettingsTab.kt   # Pantalla de transparencia de medios guardados
    │       │               ├── UserPublicFolderCard.kt     # Selector de carpeta pública del usuario y exportación .mp4 con audio
    │       │               ├── SavedMediaStorageSection.kt # Resumen de rutas estructuradas y espacio físico
    │       │               ├── StoredMediaFormatUtils.kt   # Utilidades de formato de pesos KB/MB y relaciones de aspecto
    │       │               ├── StoredMediaSummaryHeader.kt # Cabecera estadística de portadas WebP y videos MP4
    │       │               ├── StoredMediaTrackCard.kt     # Tarjeta individual de pista con inspección y borrado selectivo
    │       │               └── StoredMediaDeleteDialogs.kt # Diálogos de confirmación para liberar almacenamiento
    │       │
    │       ├── ui/                             # Orquestador UI Global, Componentes Compartidos, Navegación y Tema M3
    │       │   ├── AuraMusicAppContent.kt      # Scaffold principal, fondo personalizado, MiniPlayer y transiciones
    │       │   ├── GlobalDialogsHost.kt        # Contenedor centralizado de diálogos y hojas modales globales
    │       │   ├── navigation/
    │       │   │   └── NavScreen.kt            # Definición de rutas principales y pestañas de biblioteca
    │       │   ├── theme/                      # Sistema de Diseño Dark Luxury Neo-Glass OLED y Extracción Cromática
    │       │   │   ├── ArtworkColorExtractor.kt # Extracción dinámica de color cada 1s (local, URLs https:// y GPU TextureView)
    │       │   │   ├── Color.kt                 # Paletas de color neón y superficies OLED 100% opacas
    │       │   │   ├── Theme.kt                 # Configuración MaterialTheme, Material You y blindaje fontScale = 1.0f
    │       │   │   └── Type.kt                  #Jerarquía tipográfica de Aura Music
    │       │   └── components/                 # Componentes Modulares Reutilizables
    │       │       ├── MiniPlayer.kt           # Mini reproductor flotante tintado con Video Canvas e indicador de red
    │       │       ├── BottomNavBar.kt         # Barra de navegación inferior con pestaña Explorar e insignia de Ajustes
    │       │       ├── TrackListItem.kt        # Elemento modular de canción con marquesina y menú contextual
    │       │       ├── AnimatedDownloadingArrowIcon.kt # Icono animado de descarga activa en barra superior
    │       │       ├── AudioEffectsBottomSheet.kt      # Hoja modal unificada del estudio acústico C++20
    │       │       ├── artwork/                # Renderizadores de Portadas, Collages, Fondo, Arte Procedural y Video
    │       │       │   ├── ArtworkImage.kt           # Cargador Coil WebP con recorte de franjas negras 4:3 (Deletterbox)
    │       │       │   ├── AppWallpaperBackground.kt # Renderizador global de fondo personalizado (Imagen WebP o Video corto)
    │       │       │   ├── PlaylistCoverCollage.kt   # Collage adaptativo automático de 1, 2, 3 o 4 portadas
    │       │       │   ├── ProceduralArtwork.kt      # Generador Canvas vectorial para canciones sin carátula
    │       │       │   ├── BackgroundVideoPlayer.kt  # Reproductor Video Canvas sin pantallas negras y muestreo GPU a 1s
    │       │       │   └── AudioVisualizer.kt        # Visualizador espectral de 28 bandas impulsado por C++20
    │       │       ├── audioeffects/           # Pestañas Modulares de la Hoja de Efectos de Audio
    │       │       │   ├── EqualizerTabContent.kt          # Pestaña del Ecualizador ISO de 10 bandas, Bass Boost y Voces HD
    │       │       │   ├── Spatial8DTabContent.kt          # Pestaña de Audio Espacial 8D Clásico y 16D Multi-Órbita
    │       │       │   ├── ReverbTabContent.kt             # Pestaña de Reverb C++20 y espacios acústicos
    │       │       │   ├── PlaybackParametersTabContent.kt # Pestaña de Velocidad/Tono (0.5x-2.0x), Voces HD y Normalizador LUFS
    │       │       │   ├── BalanceAndHeadphonesTabContent.kt # Pestaña de Balance Estéreo L/R y Crossfeed Chu Moy
    │       │       │   ├── TransitionsTabContent.kt        # Pestaña de Crossfade Dual-Deck, Smart AutoMix DJ y Bucle A-B
    │       │       │   └── SleepTimerTabContent.kt         # Pestaña del Temporizador de Apagado con Fade-Out de 10s
    │       │       ├── banners/                # Banners Superiores No Intrusivos
    │       │       │   ├── PackageUpdateBanner.kt     # Banner de verificación y actualización OTA de yt-dlp
    │       │       │   └── SettingsDiscoveryBanner.kt # Aviso interactivo para descubrir Ajustes en el primer uso
    │       │       ├── dialogs/                # Diálogos Modales Globales
    │       │       │   ├── AppUpdateDialog.kt              # Modal de descarga e instalación de actualización APK
    │       │       │   ├── CreateMixtapeDialog.kt          # Modal unificado de Mixtape continuo y Auto-Remix de 2 pistas
    │       │       │   ├── AutoRemixConfigSection.kt       # Configurador de Mashup (Voz A + Base B), Remix DJ y Auto-Match
    │       │       │   ├── DownloadFromLinkDialog.kt       # Modal deslizable de descarga desde YouTube, TikTok y web
    │       │       │   ├── ImportExternalPlaylistDialog.kt # Modal de importación de Playlists de Spotify y YouTube Music
    │       │       │   ├── EditTrackDialog.kt              # Editor de metadatos, portada WebP y Video Canvas
    │       │       │   ├── SearchLyricsDialog.kt           # Buscador interactivo de letras LRCLIB con recomendación #1
    │       │       │   └── VideoToMusicDialog.kt           # Conversor 3 en 1 de Video a Música (.m4a + WebP + Canvas)
    │       │       └── download/               # Subcomponentes del Modal de Descargas Web
    │       │           ├── DownloadProgressStatusCard.kt      # Tarjeta de progreso en vivo (MB/s, porcentaje y 2do plano)
    │       │           ├── DownloadSourceAndEngineSelector.kt # Selector interactivo de motor (yt-dlp, InnerTube, WebView)
    │       │           ├── DownloadResolvedMediaCard.kt       # Previsualización de portada, título y edición rápida
    │       │           └── DownloadCanvasOptionsSection.kt    # Opciones de Video Canvas 480p, Boomerang/Crossfade y silencios
    │       │
    │       ├── viewmodel/                      # Capa ViewModel y Coordinadores MVVM
    │       │   ├── MusicViewModel.kt           # ViewModel principal desacoplado
    │       │   └── delegates/
    │       │       ├── AudioEffectsCoordinator.kt      # Coordinador de efectos C++20, Normalizador, AutoMix y Sleep Timer
    │       │       ├── NavigationCoordinator.kt        # Coordinador de navegación, temas, fondo de galería y modos visuales
    │       │       ├── TrackLibraryCoordinator.kt      # Operaciones de biblioteca, playlists, SAF y descargas
    │       │       ├── LyricsCoordinator.kt            # Coordinación de letras sincronizadas LRCLIB y archivos .lrc/.txt
    │       │       ├── IncomingMediaCoordinator.kt     # Recepción de Intents externos (audios, videos, URLs y Playlists)
    │       │       ├── HeadphoneSettingsCoordinator.kt # Ajustes de auriculares, Crossfeed, Bit-Perfect y AAudio
    │       │       ├── MixtapeCoordinator.kt           # Coordinador de Mixtapes, Auto-Remix de 2 pistas y capítulos en vivo
    │       │       ├── StreamingModeCoordinator.kt     # Orquestador del Modo Streaming (YT Music, YouTube, SoundCloud y Caché)
    │       │       └── PlaylistImportCoordinator.kt    # Orquestador del Importador de Playlists de Spotify y YouTube Music
    │       │
    │       ├── widget/                         # Sistema de 2 Widgets Interactivos para Pantalla de Inicio
    │       │   ├── AuraMusicWidgetProvider.kt        # Widget 1: Reproductor adaptativo (4x1, 4x2, 4x3) con color de carátula
    │       │   ├── AuraLibraryWidgetProvider.kt      # Widget 2: Cuadrícula 2x2 de Top 4 Canciones o 4 Playlists principales
    │       │   ├── WidgetStateStore.kt               # Persistencia de estado, extracción Palette y caché JSON de Widgets
    │       │   ├── WidgetArtworkRenderer.kt          # Renderizador Canvas de fondos Neo-Glass, barras y collages 2x2
    │       │   └── WidgetPlaybackHeadlessController.kt # Controlador para reanudar y cambiar pistas en 2do plano con app cerrada
    │       │
    │       └── debug/                          # Suite Autónoma de Diagnóstico y Telemetría "Aura Monitor" (Solo Debug)
    │           ├── AuraDebugManager.kt               # Manejador global de excepciones (UncaughtExceptionHandler) y logs
    │           ├── DebugMonitorActivity.kt           # Actividad independiente en el launcher con pestañas de Logs y Rendimiento
    │           ├── DebugLogEntry.kt                  # Modelo de entrada de incidente o evento técnico
    │           ├── DebugSeverity.kt                  # Niveles de severidad (CRASH, CRITICAL, ERROR, WARNING, INFO)
    │           ├── DeviceDiagnosticInfo.kt           # Recolector de hardware, ABI, Android SDK, RAM y almacenamiento
    │           ├── PerformanceDiagnosticModels.kt    # Modelos de memoria segmentada (Java, Native C++, Gráficos, PSS) e hilos
    │           ├── PerformanceTelemetryManager.kt    # Monitor en vivo de RAM, CPU (%), FPS e inspector de hilos con stacktraces
    │           └── ui/
    │               ├── DebugFilterChips.kt               # Chips de filtrado por severidad en Aura Monitor
    │               ├── DebugLogEntryCard.kt              # Tarjeta resumida de incidente registrado
    │               ├── DebugLogDetailDialog.kt           # Visor detallado de stacktrace y copia al portapapeles
    │               ├── DebugSyntheticTestDialog.kt       # Generador de pruebas sintéticas de diagnóstico
    │               ├── HardwareTelemetryCard.kt          # Tarjeta de especificaciones técnicas del dispositivo
    │               └── PerformanceTelemetryTabContent.kt # Pestaña interactiva de RAM segmentada, CPU e Inspector de Hilos
    │
    ├── test/                                   # Pruebas Unitarias Locales y Robolectric (JVM)
    │   └── java/com/example/
    │       ├── ExampleUnitTest.kt              # Pruebas unitarias base
    │       └── ExampleRobolectricTest.kt       # Pruebas de integración local con Robolectric
    │
    └── androidTest/                            # Pruebas Instrumentadas Base de Plantilla Android
        └── java/com/example/
            └── ExampleInstrumentedTest.kt
```

---

## 🛡️ Blindaje y Solución de Vulnerabilidades

1. **Omisión Silenciosa de SHA-256 en Actualización OTA (`YtDlpAutoUpdater.kt`)**:
   - `expectedSha256` es de verificación estricta obligatoria.
   - Si no se obtiene la suma criptográfica oficial desde `SHA2-256SUMS`, la actualización se cancela inmediatamente con registro de incidente en Aura Monitor.
   - No se permite la instalación de binarios ejecutables sin validación de integridad previa.

2. **Desactivación Global de Verificación TLS/SSL en yt-dlp (`YtDlpNativeEngine.kt`)**:
   - Eliminado el argumento permisivo `--no-check-certificates` tanto en la ejecución inicial como en el bloque de reintento ante errores SSL.
   - Inyección rigurosa y reconstrucción bajo demanda (`forceRebuild = true`) del almacén de certificados CA oficial (`cert.pem` embebido local en `/usr/etc/tls/cert.pem`, Conscrypt APEX `/apex/com.android.conscrypt/cacerts` y `/system/etc/security/cacerts`).

3. **Blindaje de Memoria Nativa C++20 y Sincronización Thread-Safe (`auramusic_dsp.cpp`)**:
   - Validación estricta de capacidad en `DirectByteBuffer` mediante `GetDirectBufferCapacity(byteBuffer)` previniendo lecturas o escrituras fuera de límites (*Buffer Over-read / Over-write*).
   - Sincronización mediante `std::mutex` (`sDspMutex`) entre el hilo de audio PCM de ExoPlayer y los ajustes en tiempo real de la interfaz.

4. **Protección contra Path Traversal, File Stealing y SSRF (`AppStorageManager.kt`, `IncomingMediaHandler.kt`, `InvidiousStreamResolver.kt`, `TikTokMediaResolver.kt`)**:
   - Resolución canónica obligatoria (`resolveSafeChildFile` e `isInsideDirectoryCanonical`) en `AppStorageManager.kt` al guardar y eliminar canciones, carátulas, letras y metadatos.
   - Bloqueo de ataques *File Stealing* por enlaces simbólicos o URIs que apunten al sandbox privado interno (`dataDir`, `filesDir`, `cacheDir`) en `IncomingMediaHandler.kt` y eliminación del esquema inseguro `file://` en `AndroidManifest.xml`.
   - Exclusión de binarios ejecutables (`bin/`, `env/`) y logs en `backup_rules.xml` y `data_extraction_rules.xml`.
   - Validación estricta de esquema `https://` y bloqueo de direcciones IP privadas/loopback (anti-SSRF) en `InvidiousStreamResolver.kt` y `TikTokMediaResolver.kt`.

5. **Riesgo de Colisión de Nombres y Extensiones en SAF (`SafTrackImporter.kt`)**:
   - Normalización de nombres de archivo y sanitización contra secuencias de escape y caracteres peligrosos (`..`, `/`, `\`).
   - Mapeo estricto del MIME Type hacia extensiones de audio permitidas (`mp3`, `m4a`, `flac`, `wav`, `ogg`, `opus`, `aac`).
   - Desambiguación con sufijos UUID aleatorios (`_a1b2c3`) para evitar sobreescritura accidental de pistas previas.

6. **Prevención de Inyección de Opciones (Flag Injection) en FFmpeg (`FFmpegNativeEngine.kt`)**:
   - Sanitización de rutas canónicas de entrada y salida mediante `sanitizeFilePath()`.
   - Rechazo de rutas que comiencen con `-` o contengan saltos de línea/espacios sospechosos.
   - Inserción del delimitador POSIX `--` antes de argumentos posicionales en invocaciones nativas para neutralizar la interpretación accidental de rutas como banderas de línea de comandos.

7. **Sandbox Estricto en WebView, Guardián Anti-SSRF/DNS Rebinding y Autenticación IPC (`HeadlessWebViewExtractor.kt`, `ChunkedStreamDownloader.kt`, `AuraMediaPlaybackService.kt`, `MainActivity.kt`, `native_ffmpeg_launcher.c`)**:
   - Desactivación explícita de `allowFileAccess`, `allowContentAccess`, `allowFileAccessFromFileURLs` y `allowUniversalAccessFromFileURLs` en `HeadlessWebViewExtractor`, más validación de `videoId` y `shouldOverrideUrlLoading`.
   - Interceptor anti-SSRF / anti-DNS Rebinding en `ChunkedStreamDownloader` y comprobación estricta del host real parseado antes de adjuntar cookies de sesión.
   - Autorización de paquete/UID en `AuraMediaPlaybackService.onGetSession()` y token criptográfico interno (`INTERNAL_IPC_AUTH_TOKEN`) para comandos del Widget y notificaciones en `MainActivity`.
   - Verificación con `stat()` en C (`native_ffmpeg_launcher.c` y `native_python_launcher.c`) rechazando bibliotecas escribibles por terceros (`S_IWOTH`) antes de `dlopen()`.

8. **Escáner Automatizado Manual en GitHub Actions (`.github/workflows/security-vulnerability-audit.yml`)**:
   - Flujo `workflow_dispatch` ("Escáner de Seguridad y Vulnerabilidades (Aura Shield)") con análisis multicapa (Gitleaks, Google OSV-Scanner, Semgrep Kotlin/C++20, Invariantes de Seguridad de Aura Music y Android Lint opcional) y reporte ejecutivo en español en `$GITHUB_STEP_SUMMARY` optimizado para lectura desde teléfono móvil.

