package com.example.feature.nowplaying
import com.example.core.model.LyricsState
import com.example.core.model.RepeatMode

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.StateFlow
import com.example.core.model.ABLoopState
import com.example.core.model.EqualizerBand
import com.example.core.model.EqualizerPreset
import com.example.core.model.EqualizerScopeMode
import com.example.core.model.HeadphoneConfig
import com.example.core.model.ReverbConfig
import com.example.core.model.ReverbPreset
import com.example.core.model.SleepTimerState
import com.example.core.model.Spatial8DConfig
import com.example.core.model.Track
import com.example.core.model.VideoDisplayMode
import com.example.ui.components.AudioEffectsBottomSheet
import com.example.ui.components.AudioVisualizer
import com.example.ui.components.BackgroundVideoPlayer
import com.example.ui.components.EditTrackDialog
import com.example.ui.components.SearchLyricsDialog
import com.example.core.model.LyricSearchResult
import com.example.core.model.NowPlayingDesignMode
import com.example.feature.nowplaying.components.*
import com.example.ui.theme.ArtworkColorExtractor
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.ExtractedArtworkColors
import com.example.ui.theme.TextSecondary

/**
 * Pantalla completa de Reproducción en Curso (Now Playing).
 * Arquitectura Modular (MVVM):
 * Orquestador principal de UI que integra submódulos especializados en [com.example.feature.nowplaying.components]:
 * - [NowPlayingTopBar]: Barra superior con botones de colapso, insignia de efectos, video y ficha técnica.
 * - [NowPlayingArtworkCard]: Carátula flotante y soporte para los 3 modos de Video Canvas.
 * - [AudioVisualizer]: Visualizador animado de ondas en tiempo real.
 * - [NowPlayingPlaybackControls]: Información de pista, favorito, barra de progreso interactiva (Seekbar) y controles de reproducción.
 * - [NowPlayingBalanceBar]: Control de Balance Estéreo L/R en vivo con centrado a 0%.
 * - [NowPlayingQueueSheet]: Hoja modal de la cola de reproducción ("Up Next").
 * - [AudioSpecsDialog]: Ficha técnica de audio y acceso a edición.
 * - [VideoDisplayModeDialog]: Diálogo de selección de los 3 modos de video.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    currentTrack: Track?,
    isPlaying: Boolean,
    currentPositionMs: Long = 0L,
    currentPositionFlow: StateFlow<Long>? = null,
    durationMs: Long,
    shuffleEnabled: Boolean,
    repeatMode: RepeatMode,
    queue: List<Track>,
    currentIndex: Int,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onPlayNext: () -> Unit,
    onPlayPrevious: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: (Track) -> Unit,
    onTrackSelectFromQueue: (Int) -> Unit,
    onOpenEqualizer: () -> Unit,
    onCollapse: () -> Unit,
    onEditTrack: ((trackId: Long, newTitle: String, newArtist: String, newAlbum: String) -> Unit)? = null,
    onEditTrackDetails: ((trackId: Long, newTitle: String, newArtist: String, newAlbum: String, customArtUri: android.net.Uri?, removeArtwork: Boolean) -> Unit)? = null,
    onEditTrackDetailsWithVideo: ((trackId: Long, newTitle: String, newArtist: String, newAlbum: String, customArtUri: android.net.Uri?, removeArtwork: Boolean, customVideoUri: android.net.Uri?, removeVideo: Boolean, forceLoop: Boolean?) -> Unit)? = null,
    onEditTrackDetailsWithLoopStyle: ((trackId: Long, newTitle: String, newArtist: String, newAlbum: String, customArtUri: android.net.Uri?, removeArtwork: Boolean, customVideoUri: android.net.Uri?, removeVideo: Boolean, forceLoop: Boolean?, loopStyle: com.example.core.data.importer.FFmpegNativeEngine.CanvasLoopStyle) -> Unit)? = null,
    isVideoCanvasActive: Boolean = true,
    videoDisplayMode: VideoDisplayMode = VideoDisplayMode.FULLSCREEN_BACKGROUND,
    isDynamicArtworkColorEnabled: Boolean = true,
    onToggleVideoCanvas: () -> Unit = {},
    onSetVideoDisplayMode: (VideoDisplayMode) -> Unit = {},
    onCycleVideoDisplayMode: () -> Unit = {},
    sleepTimerState: SleepTimerState = SleepTimerState(),
    onStartSleepTimer: (Int) -> Unit = {},
    onCancelSleepTimer: () -> Unit = {},
    onAddSleepTimerMinutes: (Int) -> Unit = {},
    spatial8DConfig: Spatial8DConfig = Spatial8DConfig(),
    onSet8DEnabled: (Boolean) -> Unit = {},
    onSet8DMode16D: (Boolean) -> Unit = {},
    onSet8DOrbitSpeed: (Float) -> Unit = {},
    onSet8DSpatialIntensity: (Float) -> Unit = {},
    onSet8DRoomDepth: (Float) -> Unit = {},
    // Clarificador de Voces HD C++20 (Mid-Side)
    vocalClarityConfig: com.example.core.model.VocalClarityConfig = com.example.core.model.VocalClarityConfig(),
    onSetVocalClarityEnabled: (Boolean) -> Unit = {},
    onSetVocalClarityStrength: (Float) -> Unit = {},
    // Suite Reverb & Filtros Acústicos
    reverbConfig: ReverbConfig = ReverbConfig(),
    onSetReverbEnabled: (Boolean) -> Unit = {},
    onSetReverbPreset: (ReverbPreset) -> Unit = {},
    onSetReverbCustomParameters: (roomSize: Float, decayMs: Int, levelDb: Float) -> Unit = { _, _, _ -> },
    playbackSpeed: Float = 1.0f,
    onSetPlaybackSpeed: (Float) -> Unit = {},
    playbackPitch: Float = 1.0f,
    onSetPlaybackPitch: (Float) -> Unit = {},
    onResetSpeedAndPitch: () -> Unit = {},
    crossfadeSeconds: Int = 0,
    onSetCrossfadeSeconds: (Int) -> Unit = {},
    isGaplessEnabled: Boolean = true,
    onSetGaplessEnabled: (Boolean) -> Unit = {},
    isDjAutomixEnabled: Boolean = false,
    onSetDjAutomixEnabled: (Boolean) -> Unit = {},
    isDjEqCurveEnabled: Boolean = true,
    onSetDjEqCurveEnabled: (Boolean) -> Unit = {},
    volumeNormalizationConfig: com.example.core.model.VolumeNormalizationConfig = com.example.core.model.VolumeNormalizationConfig(),
    onSetVolumeNormalizationEnabled: (Boolean) -> Unit = {},
    onSetVolumeNormalizationMode: (Int) -> Unit = {},
    // Repetidor de Segmento A-B
    abLoopState: ABLoopState = ABLoopState(),
    onMarkABPointA: () -> Unit = {},
    onMarkABPointB: () -> Unit = {},
    onToggleABLoopEnabled: (Boolean) -> Unit = {},
    onAdjustABPointA: (Long) -> Unit = {},
    onAdjustABPointB: (Long) -> Unit = {},
    onClearABLoop: () -> Unit = {},
    // Parámetros de Ecualizador C++20 integrados (desactivado por defecto)
    isEqEnabled: Boolean = false,
    eqScopeMode: EqualizerScopeMode = EqualizerScopeMode.GLOBAL_ALL_TRACKS,
    onSetEqScopeMode: (EqualizerScopeMode) -> Unit = {},
    eqBands: List<EqualizerBand> = emptyList(),
    bassBoostLevel: Int = 0,
    currentPreset: EqualizerPreset = EqualizerPreset.PRESETS.first(),
    onToggleEqEnabled: (Boolean) -> Unit = {},
    onBandLevelChange: (Int, Int) -> Unit = { _, _ -> },
    onBassBoostChange: (Int) -> Unit = {},
    onPresetSelect: (EqualizerPreset) -> Unit = {},
    // Auriculares & Balance Estéreo Fino
    headphoneConfig: HeadphoneConfig = HeadphoneConfig(),
    onSetCrossfeedEnabled: (Boolean) -> Unit = {},
    onSetCrossfeedStrength: (Int) -> Unit = {},
    onSetBalanceControlEnabled: (Boolean) -> Unit = {},
    onSetStereoBalance: (Float) -> Unit = {},
    // Visualizador espectral C++20, intensidad acústica y Letras Sincronizadas
    visualizerBands: FloatArray? = null,
    visualizerBandsFlow: StateFlow<FloatArray>? = null,
    audioIntensity: Float = 0.15f,
    audioIntensityFlow: StateFlow<Float>? = null,
    lyricsState: com.example.core.model.LyricsState = com.example.core.model.LyricsState(),
    isSearchLyricsDialogOpen: Boolean = false,
    isSearchingLyrics: Boolean = false,
    lyricsSearchResults: List<LyricSearchResult> = emptyList(),
    searchLyricsError: String? = null,
    onFetchOnlineLyrics: () -> Unit = {},
    onSaveCustomLyrics: (String) -> Unit = {},
    onImportLyricsUri: (android.net.Uri) -> Unit = {},
    onOpenSearchLyrics: () -> Unit = {},
    onCloseSearchLyrics: () -> Unit = {},
    onSearchLyrics: (title: String, artist: String) -> Unit = { _, _ -> },
    onSelectLyricSearchResult: (LyricSearchResult) -> Unit = {},
    activeMixtapeChapter: com.example.core.model.MixtapeChapter? = null,
    mixtapeChapterIndex: Int = -1,
    mixtapeTotalChapters: Int = 0,
    nowPlayingDesignMode: NowPlayingDesignMode = NowPlayingDesignMode.AUTO,
    onSetNowPlayingDesignMode: (NowPlayingDesignMode) -> Unit = {},
    collectionContextTitle: String = "Tu Biblioteca",
    onDownloadStreamingTrack: ((Track) -> Unit)? = null,
    isStreamingTrackDownloading: Boolean = false,
    isStreamingTrackDownloaded: Boolean = false,
    isLoadingOrBuffering: Boolean = false,
    isWaitingForNetwork: Boolean = false,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onCollapse()
    }

    if (currentTrack == null) return

    val context = LocalContext.current
    val fallbackPrimary = MaterialTheme.colorScheme.primary
    val fallbackSecondary = MaterialTheme.colorScheme.secondary

    var activeColors by remember {
        mutableStateOf(
            ExtractedArtworkColors(
                primary = fallbackPrimary,
                secondary = fallbackSecondary,
                accent = fallbackPrimary,
                ambientTopGlow = fallbackPrimary.copy(alpha = 0.28f)
            )
        )
    }

    val isVideoVisual = (videoDisplayMode != VideoDisplayMode.OFF) && !currentTrack.videoUri.isNullOrEmpty()
    val isRemoteVideo = isVideoVisual && (
        currentTrack.videoUri.orEmpty().startsWith("http://", ignoreCase = true) ||
            currentTrack.videoUri.orEmpty().startsWith("https://", ignoreCase = true)
        )
    val liveVideoSnapshot by ArtworkColorExtractor.liveVideoColorsFlow.collectAsStateWithLifecycle()
    val isVideoBufferingLive by com.example.ui.components.BackgroundVideoLoadingState.isVideoBufferingFlow.collectAsStateWithLifecycle()
    val isVideoNetworkStalledLive by com.example.ui.components.BackgroundVideoLoadingState.isVideoNetworkStalledFlow.collectAsStateWithLifecycle()
    val effectiveVideoLoading = currentTrack.isStreamingTrack && isRemoteVideo && isVideoBufferingLive
    val effectiveWaitingNetwork = currentTrack.isStreamingTrack && (isWaitingForNetwork || (isRemoteVideo && isVideoNetworkStalledLive))
    var activeSampleIntervalMs by remember {
        mutableLongStateOf(ArtworkColorExtractor.getAdaptiveSampleIntervalMs(context))
    }

    // Extracción inicial y respaldo reactivo cuando cambia la pista, modo de video o preferencia
    LaunchedEffect(
        currentTrack.id,
        currentTrack.albumArtPath,
        currentTrack.videoUri,
        videoDisplayMode,
        isDynamicArtworkColorEnabled
    ) {
        activeSampleIntervalMs = ArtworkColorExtractor.getAdaptiveSampleIntervalMs(context)
        activeColors = ArtworkColorExtractor.extractPlaybackColors(
            context = context,
            track = currentTrack,
            isVideoActive = isVideoVisual,
            isDynamicEnabled = isDynamicArtworkColorEnabled,
            fallbackPrimary = fallbackPrimary,
            fallbackSecondary = fallbackSecondary,
            positionMs = currentPositionFlow?.value ?: currentPositionMs
        )
    }

    // Recibir instantáneamente cada cambio de paleta emitido en tiempo real por el TextureView del video
    LaunchedEffect(liveVideoSnapshot, isVideoVisual, isDynamicArtworkColorEnabled, currentTrack.videoUri) {
        if (isDynamicArtworkColorEnabled && isVideoVisual) {
            val snapshot = liveVideoSnapshot
            if (snapshot != null && snapshot.videoUri == currentTrack.videoUri) {
                activeSampleIntervalMs = snapshot.sampleIntervalMs
                activeColors = snapshot.colors
            }
        }
    }

    val colorTransitionDurationMs = if (isVideoVisual && isDynamicArtworkColorEnabled) {
        if (activeSampleIntervalMs <= ArtworkColorExtractor.INTERVAL_NORMAL_MS) 1000 else 1400
    } else {
        600
    }

    val animatedPrimary by animateColorAsState(
        targetValue = activeColors.primary,
        animationSpec = tween(colorTransitionDurationMs),
        label = "PrimaryAuraColor"
    )
    val animatedSecondary by animateColorAsState(
        targetValue = activeColors.secondary,
        animationSpec = tween(colorTransitionDurationMs),
        label = "SecondaryAuraColor"
    )
    val animatedTopGlow by animateColorAsState(
        targetValue = activeColors.ambientTopGlow,
        animationSpec = tween(colorTransitionDurationMs),
        label = "TopAuraGlow"
    )

    var showQueueSheet by remember { mutableStateOf(false) }
    var showEffectsSheet by remember { mutableStateOf(false) }
    var effectsInitialTab by remember { mutableIntStateOf(0) }
    var showDetailsDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showVideoModeDialog by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var isFullScreenLyricsOpen by remember { mutableStateOf(false) }
    var showDesignSelectorDialog by remember { mutableStateOf(false) }

    val hasVideo = !currentTrack.videoUri.isNullOrEmpty()
    val isFullscreenVideo = hasVideo && videoDisplayMode.isFullscreen

    // Determinación del diseño visual activo (Automático o forzado por el usuario)
    val isCinematicActive = remember(nowPlayingDesignMode, isFullscreenVideo, currentTrack.videoUri) {
        when (nowPlayingDesignMode) {
            NowPlayingDesignMode.CINEMATIC_CANVAS -> true
            NowPlayingDesignMode.CLASSIC -> false
            NowPlayingDesignMode.AUTO -> isFullscreenVideo && !currentTrack.videoUri.isNullOrEmpty()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .pointerInput(Unit) {
                detectTapGestures {
                    // Consumir toques en áreas vacías para que no traspasen a las pantallas de fondo
                }
            }
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                // Interceptar clics residuales en cualquier espacio de NowPlayingScreen
            }
            .testTag("now_playing_screen")
    ) {
        // Modo FONDO COMPLETO (Rellenar o Adaptado): Renderiza el video detrás de toda la pantalla
        if (isFullscreenVideo && currentTrack.videoUri != null) {
            key(currentTrack.id, currentTrack.videoUri) {
                BackgroundVideoPlayer(
                    videoUriString = currentTrack.videoUri,
                    isVideoLoop = currentTrack.isVideoLoop,
                    isPlaying = isPlaying,
                    currentPositionMs = currentPositionMs,
                    currentPositionFlow = currentPositionFlow,
                    playbackSpeed = playbackSpeed,
                    placeholderTrack = currentTrack,
                    modifier = Modifier.fillMaxSize(),
                    cornerRadius = 0.dp,
                    fitHorizontalInFullscreen = (videoDisplayMode == VideoDisplayMode.FULLSCREEN_ADAPTED)
                )
            }

            // Velo oscuro y gradiente cinematográfico para máximo contraste y legibilidad
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.65f),
                                Color.Black.copy(alpha = 0.50f),
                                BackgroundDark.copy(alpha = 0.94f)
                            )
                        )
                    )
            )
        }

        // Halo de luz ambiental decorativo aislado en su propio componente pequeño
        // para que audioIntensity NO recomponga toda NowPlayingScreen
        NowPlayingAmbientTopGlow(
            animatedTopGlow = animatedTopGlow,
            isFullscreenVideo = isFullscreenVideo,
            fallbackIntensity = audioIntensity,
            audioIntensityFlow = audioIntensityFlow
        )

        if (isCinematicActive && !showLyrics) {
            NowPlayingCinematicLayout(
                currentTrack = currentTrack,
                isPlaying = isPlaying,
                currentPositionMs = currentPositionMs,
                currentPositionFlow = currentPositionFlow,
                durationMs = durationMs,
                shuffleEnabled = shuffleEnabled,
                repeatMode = repeatMode,
                lyricsState = lyricsState,
                animatedPrimary = animatedPrimary,
                animatedSecondary = animatedSecondary,
                audioIntensity = audioIntensity,
                audioIntensityFlow = audioIntensityFlow,
                onTogglePlayPause = onTogglePlayPause,
                onSeekTo = onSeekTo,
                onPlayNext = onPlayNext,
                onPlayPrevious = onPlayPrevious,
                onToggleShuffle = onToggleShuffle,
                onCycleRepeat = onCycleRepeat,
                onToggleFavorite = onToggleFavorite,
                onCollapse = onCollapse,
                onOpenEffects = {
                    effectsInitialTab = 1
                    showEffectsSheet = true
                },
                onOpenQueue = { showQueueSheet = true },
                onOpenDesignSelector = { showDesignSelectorDialog = true },
                onOpenLyrics = { showLyrics = true },
                onOpenFullScreenLyrics = { isFullScreenLyricsOpen = true },
                onOpenDetails = { showDetailsDialog = true },
                collectionContextTitle = collectionContextTitle,
                onDownloadStreamingTrack = if (currentTrack.isStreamingTrack && onDownloadStreamingTrack != null) {
                    { onDownloadStreamingTrack(currentTrack) }
                } else null,
                isStreamingTrackDownloading = isStreamingTrackDownloading,
                isStreamingTrackDownloaded = isStreamingTrackDownloaded,
                isLoadingOrBuffering = isLoadingOrBuffering,
                isVideoLoading = effectiveVideoLoading,
                isWaitingForNetwork = effectiveWaitingNetwork
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Barra Superior
                NowPlayingTopBar(
                    currentTrack = currentTrack,
                    sleepTimerState = sleepTimerState,
                    spatial8DConfig = spatial8DConfig,
                    videoDisplayMode = videoDisplayMode,
                    animatedPrimary = animatedPrimary,
                    onCollapse = onCollapse,
                    onOpenEffects = {
                        effectsInitialTab = 1
                        showEffectsSheet = true
                    },
                    onOpenDetails = { showDetailsDialog = true },
                    onOpenVideoMode = { showVideoModeDialog = true },
                    isLyricsActive = showLyrics,
                    onToggleLyrics = { showLyrics = !showLyrics },
                    isABLoopActive = abLoopState.isLoopingActive,
                    isVocalClarityActive = vocalClarityConfig.enabled,
                    onOpenDesignSelector = { showDesignSelectorDialog = true },
                    onDownloadStreamingTrack = if (currentTrack.isStreamingTrack && onDownloadStreamingTrack != null) {
                        { onDownloadStreamingTrack(currentTrack) }
                    } else null,
                    isStreamingTrackDownloading = isStreamingTrackDownloading,
                    isStreamingTrackDownloaded = isStreamingTrackDownloaded
                )

            Spacer(modifier = Modifier.weight(0.5f))

            // Carátula / Video Canvas O Letras Sincronizadas (.LRC) Karaoke
            if (showLyrics) {
                NowPlayingLyricsCard(
                    currentTrack = currentTrack,
                    lyricsState = lyricsState,
                    currentPositionMs = currentPositionMs,
                    currentPositionFlow = currentPositionFlow,
                    animatedPrimary = animatedPrimary,
                    onSeekTo = onSeekTo,
                    onFetchOnlineLyrics = onFetchOnlineLyrics,
                    onSaveCustomLyrics = onSaveCustomLyrics,
                    onImportLyricsUri = onImportLyricsUri,
                    onOpenSearchLyrics = onOpenSearchLyrics,
                    onOpenFullScreen = { isFullScreenLyricsOpen = true },
                    onCloseLyrics = { showLyrics = false }
                )
            } else {
                NowPlayingArtworkCard(
                    currentTrack = currentTrack,
                    isPlaying = isPlaying,
                    currentPositionMs = currentPositionMs,
                    currentPositionFlow = currentPositionFlow,
                    videoDisplayMode = videoDisplayMode,
                    animatedPrimary = animatedPrimary,
                    animatedSecondary = animatedSecondary,
                    playbackSpeed = playbackSpeed,
                    onCycleVideoDisplayMode = onCycleVideoDisplayMode,
                    audioIntensity = audioIntensity,
                    onOpenVideoMode = { showVideoModeDialog = true },
                    isLoadingOrBuffering = isLoadingOrBuffering || effectiveVideoLoading,
                    isWaitingForNetwork = effectiveWaitingNetwork
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Visualizador dinámico de audio en tiempo real aislado (recolecta bandsFlow localmente)
            AudioVisualizer(
                isPlaying = isPlaying,
                realBands = visualizerBands,
                bandsFlow = visualizerBandsFlow,
                modifier = Modifier.fillMaxWidth(0.9f),
                barCount = 28,
                barHeight = 40.dp,
                customPrimaryColor = animatedPrimary,
                customSecondaryColor = animatedSecondary
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Controles de Reproducción y Seekbar
            NowPlayingPlaybackControls(
                currentTrack = currentTrack,
                isPlaying = isPlaying,
                currentPositionMs = currentPositionMs,
                currentPositionFlow = currentPositionFlow,
                durationMs = durationMs,
                shuffleEnabled = shuffleEnabled,
                repeatMode = repeatMode,
                animatedPrimary = animatedPrimary,
                onTogglePlayPause = onTogglePlayPause,
                onSeekTo = onSeekTo,
                onPlayNext = onPlayNext,
                onPlayPrevious = onPlayPrevious,
                onToggleShuffle = onToggleShuffle,
                onCycleRepeat = onCycleRepeat,
                onToggleFavorite = onToggleFavorite,
                abLoopState = abLoopState,
                onMarkABPointA = onMarkABPointA,
                onMarkABPointB = onMarkABPointB,
                onClearABLoop = onClearABLoop,
                activeMixtapeChapter = activeMixtapeChapter,
                mixtapeChapterIndex = mixtapeChapterIndex,
                mixtapeTotalChapters = mixtapeTotalChapters,
                isLoadingOrBuffering = isLoadingOrBuffering || effectiveVideoLoading,
                isWaitingForNetwork = effectiveWaitingNetwork
            )

            // Barra de Balance Estéreo Fino L/R en Tiempo Real
            NowPlayingBalanceBar(
                headphoneConfig = headphoneConfig,
                onSetStereoBalance = onSetStereoBalance,
                modifier = Modifier.padding(top = 10.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Atajos Inferiores: Ecualizador, Letras Karaoke y Cola de Reproducción
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Ecualizador
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.05f),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable {
                            effectsInitialTab = 0
                            showEffectsSheet = true
                        }
                        .testTag("now_playing_eq_shortcut")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = animatedSecondary,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "EQ FX",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = animatedSecondary,
                                fontSize = 12.sp
                            ),
                            maxLines = 1
                        )
                    }
                }

                // Letras / Carátula
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.05f),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { showLyrics = !showLyrics }
                        .testTag("now_playing_lyrics_shortcut")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (showLyrics) Icons.Default.Album else Icons.Default.Mic,
                            contentDescription = null,
                            tint = if (showLyrics) animatedPrimary else TextSecondary,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (showLyrics) "Carátula" else "Letras",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (showLyrics) FontWeight.Bold else FontWeight.Medium,
                                color = if (showLyrics) animatedPrimary else TextSecondary,
                                fontSize = 12.sp
                            ),
                            maxLines = 1
                        )
                    }
                }

                // Cola de Reproducción
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.05f),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { showQueueSheet = true }
                        .testTag("now_playing_queue_btn")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QueueMusic,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Cola (${queue.size})",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Medium,
                                color = TextSecondary,
                                fontSize = 12.sp
                            ),
                            maxLines = 1
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.5f))
        }
    }

        // Hoja Inferior: Cola de Reproducción (Up Next)
        if (showQueueSheet) {
            NowPlayingQueueSheet(
                queue = queue,
                currentIndex = currentIndex,
                isPlaying = isPlaying,
                onTrackSelect = onTrackSelectFromQueue,
                onDismissRequest = { showQueueSheet = false }
            )
        }

        // Diálogo de detalles técnicos de la pista
        if (showDetailsDialog) {
            AudioSpecsDialog(
                currentTrack = currentTrack,
                canEdit = onEditTrack != null || onEditTrackDetails != null || onEditTrackDetailsWithVideo != null,
                onOpenEditDialog = {
                    showDetailsDialog = false
                    showEditDialog = true
                },
                onDismissRequest = { showDetailsDialog = false }
            )
        }

        // Diálogo de edición de metadatos, carátula y video
        if (showEditDialog && (onEditTrack != null || onEditTrackDetails != null || onEditTrackDetailsWithVideo != null)) {
            EditTrackDialog(
                track = currentTrack,
                onDismiss = { showEditDialog = false },
                onConfirm = { trackId, title, artist, album, customArtUri, removeArtwork, customVideoUri, removeVideo ->
                    if (onEditTrackDetailsWithVideo != null) {
                        onEditTrackDetailsWithVideo(trackId, title, artist, album, customArtUri, removeArtwork, customVideoUri, removeVideo, null)
                    } else if (onEditTrackDetails != null) {
                        onEditTrackDetails(trackId, title, artist, album, customArtUri, removeArtwork)
                    } else if (onEditTrack != null) {
                        onEditTrack(trackId, title, artist, album)
                    }
                },
                onConfirmWithLoopOption = { trackId, title, artist, album, customArtUri, removeArtwork, customVideoUri, removeVideo, forceLoop ->
                    if (onEditTrackDetailsWithVideo != null) {
                        onEditTrackDetailsWithVideo(trackId, title, artist, album, customArtUri, removeArtwork, customVideoUri, removeVideo, forceLoop)
                    } else if (onEditTrackDetails != null) {
                        onEditTrackDetails(trackId, title, artist, album, customArtUri, removeArtwork)
                    } else if (onEditTrack != null) {
                        onEditTrack(trackId, title, artist, album)
                    }
                },
                onConfirmWithLoopStyle = { trackId, title, artist, album, customArtUri, removeArtwork, customVideoUri, removeVideo, forceLoop, loopStyle ->
                    if (onEditTrackDetailsWithLoopStyle != null) {
                        onEditTrackDetailsWithLoopStyle(trackId, title, artist, album, customArtUri, removeArtwork, customVideoUri, removeVideo, forceLoop, loopStyle)
                    } else if (onEditTrackDetailsWithVideo != null) {
                        onEditTrackDetailsWithVideo(trackId, title, artist, album, customArtUri, removeArtwork, customVideoUri, removeVideo, forceLoop)
                    } else if (onEditTrackDetails != null) {
                        onEditTrackDetails(trackId, title, artist, album, customArtUri, removeArtwork)
                    } else if (onEditTrack != null) {
                        onEditTrack(trackId, title, artist, album)
                    }
                }
            )
        }

        // Diálogo de selección de modo de video
        if (showVideoModeDialog && hasVideo) {
            VideoDisplayModeDialog(
                videoDisplayMode = videoDisplayMode,
                animatedPrimary = animatedPrimary,
                onSetVideoDisplayMode = onSetVideoDisplayMode,
                onDismissRequest = { showVideoModeDialog = false }
            )
        }

        // Hoja modal unificada de efectos de audio
        if (showEffectsSheet) {
            AudioEffectsBottomSheet(
                onDismissRequest = { showEffectsSheet = false },
                isEqEnabled = isEqEnabled,
                eqScopeMode = eqScopeMode,
                onSetEqScopeMode = onSetEqScopeMode,
                eqBands = eqBands,
                bassBoostLevel = bassBoostLevel,
                currentPreset = currentPreset,
                onToggleEqEnabled = onToggleEqEnabled,
                onBandLevelChange = onBandLevelChange,
                onBassBoostChange = onBassBoostChange,
                onPresetSelect = onPresetSelect,
                vocalClarityConfig = vocalClarityConfig,
                onSetVocalClarityEnabled = onSetVocalClarityEnabled,
                onSetVocalClarityStrength = onSetVocalClarityStrength,
                sleepTimerState = sleepTimerState,
                onStartSleepTimer = onStartSleepTimer,
                onCancelSleepTimer = onCancelSleepTimer,
                onAddSleepTimerMinutes = onAddSleepTimerMinutes,
                spatial8DConfig = spatial8DConfig,
                onSet8DEnabled = onSet8DEnabled,
                onSet8DMode16D = onSet8DMode16D,
                onSet8DOrbitSpeed = onSet8DOrbitSpeed,
                onSet8DSpatialIntensity = onSet8DSpatialIntensity,
                onSet8DRoomDepth = onSet8DRoomDepth,
                reverbConfig = reverbConfig,
                onSetReverbEnabled = onSetReverbEnabled,
                onSetReverbPreset = onSetReverbPreset,
                onSetReverbCustomParameters = onSetReverbCustomParameters,
                playbackSpeed = playbackSpeed,
                onSetPlaybackSpeed = onSetPlaybackSpeed,
                playbackPitch = playbackPitch,
                onSetPlaybackPitch = onSetPlaybackPitch,
                onResetSpeedAndPitch = onResetSpeedAndPitch,
                crossfadeSeconds = crossfadeSeconds,
                onSetCrossfadeSeconds = onSetCrossfadeSeconds,
                isGaplessEnabled = isGaplessEnabled,
                onSetGaplessEnabled = onSetGaplessEnabled,
                isDjAutomixEnabled = isDjAutomixEnabled,
                onSetDjAutomixEnabled = onSetDjAutomixEnabled,
                isDjEqCurveEnabled = isDjEqCurveEnabled,
                onSetDjEqCurveEnabled = onSetDjEqCurveEnabled,
                volumeNormalizationConfig = volumeNormalizationConfig,
                onSetVolumeNormalizationEnabled = onSetVolumeNormalizationEnabled,
                onSetVolumeNormalizationMode = onSetVolumeNormalizationMode,
                abLoopState = abLoopState,
                onMarkABPointA = onMarkABPointA,
                onMarkABPointB = onMarkABPointB,
                onToggleABLoopEnabled = onToggleABLoopEnabled,
                onAdjustABPointA = onAdjustABPointA,
                onAdjustABPointB = onAdjustABPointB,
                onClearABLoop = onClearABLoop,
                headphoneConfig = headphoneConfig,
                onSetCrossfeedEnabled = onSetCrossfeedEnabled,
                onSetCrossfeedStrength = onSetCrossfeedStrength,
                onSetBalanceControlEnabled = onSetBalanceControlEnabled,
                onSetStereoBalance = onSetStereoBalance,
                initialTab = effectsInitialTab
            )
        }

        // Diálogo para buscar letras personalizadas y elegir versiones con recomendación oficial
        if (isSearchLyricsDialogOpen) {
            SearchLyricsDialog(
                currentTrack = currentTrack,
                isSearching = isSearchingLyrics,
                searchResults = lyricsSearchResults,
                searchError = searchLyricsError,
                accentColor = animatedPrimary,
                onDismissRequest = onCloseSearchLyrics,
                onSearch = onSearchLyrics,
                onSelectResult = onSelectLyricSearchResult
            )
        }

        // Modo Karaoke a Pantalla Completa Inmersivo (Full Screen Lyrics)
        if (isFullScreenLyricsOpen && currentTrack != null) {
            FullScreenLyricsScreen(
                currentTrack = currentTrack,
                lyricsState = lyricsState,
                isPlaying = isPlaying,
                currentPositionMs = currentPositionMs,
                currentPositionFlow = currentPositionFlow,
                durationMs = durationMs,
                animatedPrimary = animatedPrimary,
                animatedSecondary = animatedSecondary,
                audioIntensity = audioIntensity,
                audioIntensityFlow = audioIntensityFlow,
                onSeekTo = onSeekTo,
                onTogglePlayPause = onTogglePlayPause,
                onPlayNext = onPlayNext,
                onPlayPrevious = onPlayPrevious,
                onClose = { isFullScreenLyricsOpen = false },
                onOpenSearchLyrics = onOpenSearchLyrics,
                onImportLyricsUri = onImportLyricsUri,
                onSaveCustomLyrics = onSaveCustomLyrics,
                onFetchOnlineLyrics = onFetchOnlineLyrics
            )
        }

        // Diálogo para seleccionar el diseño del reproductor (Clásico vs Cinemático Canvas)
        if (showDesignSelectorDialog) {
            NowPlayingDesignSelectorDialog(
                currentDesignMode = nowPlayingDesignMode,
                animatedPrimary = animatedPrimary,
                onSetDesignMode = onSetNowPlayingDesignMode,
                onDismissRequest = { showDesignSelectorDialog = false }
            )
        }
    }
}

@Composable
private fun NowPlayingAmbientTopGlow(
    animatedTopGlow: Color,
    isFullscreenVideo: Boolean,
    fallbackIntensity: Float,
    audioIntensityFlow: StateFlow<Float>?
) {
    val collectedIntensity = audioIntensityFlow?.collectAsStateWithLifecycle()
    val liveIntensity = collectedIntensity?.value ?: fallbackIntensity
    val dynamicAuraGlow = animatedTopGlow.copy(
        alpha = (0.24f + (liveIntensity.coerceIn(0f, 1f) * 0.32f)).coerceIn(0.18f, 0.75f)
    )
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        dynamicAuraGlow,
                        Color.Transparent,
                        if (isFullscreenVideo) Color.Transparent else BackgroundDark
                    )
                )
            )
    )
}