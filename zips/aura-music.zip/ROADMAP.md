# Aura Music - Roadmap de Desarrollo 🚀

Este documento traza las fases de evolución técnica y funcional para convertir a **Aura Music** en el reproductor de audio local más avanzado, visualmente atractivo y de mayor fidelidad en Android.

---

## 📌 Fase 1: Arquitectura Base y Motor Media3 (Completada ✅)

- [x] Interfaz de usuario completa con Jetpack Compose y Material Design 3.
- [x] Diseño estético Dark Luxury Neo-Glass con 5 paletas de colores vibrantes y acentos de neón.
- [x] Motor de reproducción con **Jetpack Media3 (ExoPlayer)**.
- [x] Persistencia local reactiva con **Room Database**.
- [x] Importación selectiva basada en Storage Access Framework (SAF) respetando la privacidad.
- [x] Generador de pistas sintetizadas WAV para pruebas automáticas y de primer uso.
- [x] Eliminación de dependencias de `.env` para compilación limpia y autónoma.
- [x] Elevación de requisitos mínimos a **Android 8.0 (API 26)**.

---

## ⚡ Fase 2: Motor DSP Nativo en C++20, Carátulas y Playlists (Completada ✅)

- [x] **Integración de C++20 con CMake en el APK Final**:
  - Enlace con `externalNativeBuild` y filtros ABI (`arm64-v8a`, `armeabi-v7a`, `x86_64`, `x86`).
  - Filtros IIR Bi-cuadráticos (*Peaking Biquads*) en C++20 con `std::span` y limitador anti-clipping.
  - Sincronización completa de llamadas JNI con `NativeAudioEngine`.
- [x] **Carátulas Personalizadas desde Galería**:
  - Integración del Android Photo Picker (`ActivityResultContracts.PickVisualMedia`).
  - Conversión a WebP sin pérdida en segundo plano (`Dispatchers.IO`).
  - Eliminación física de la carátula anterior para evitar basura en almacenamiento.
  - Opción de restaurar a arte procedural en cualquier momento.
- [x] **Sistema Completo de Playlists en la Biblioteca**:
  - Pestaña de Playlists completamente funcional.
  - Tarjeta especial sincronizada "Tus Me Gusta" / Favoritos.
  - Creación, nombrado y renombrado libre de playlists.
  - Diálogo modal para añadir canciones rápidamente desde la biblioteca.
- [x] **Pulido de Animaciones del Sistema**:
  - Transiciones de pantalla fluidas con `AnimatedContent` (desvanecimiento y deslizamiento).
  - Expansión y repliegue elástico de la pantalla completa Now Playing.
  - Micro-interacciones y feedback táctil enriquecido.
- [x] **Pipeline de CI/CD GitHub Actions con Caché Nativa y Orquestación Pura en Gradle (Cero `.sh`)**:
  - Workflow manual (`workflow_dispatch`) con tarea integrada `ensureDebugKeystore` en Gradle.
  - **Caché Inteligente de Binarios Nativos (`actions/cache@v4`)**: Sistema en GitHub Actions que almacena y restaura los `.so` de FFmpeg, CPython 3.11, QuickJS y el binario de `yt-dlp` en segundos, con compilación y ensamblaje autónomo mediante la tarea `:app:provisionNativeDeps` en `app/build.gradle.kts` ante cache-miss o actualización de parámetros.

---

## 🎧 Fase 3: Audio 8D Espacial en C++20, Temporizador y Control de Reproducción (Completada ✅)

- [x] **Motor Nativo de Audio 8D Binaural para Auriculares (ISO C++20)**:
  - Algoritmo de rotación orbital continua de potencia constante con control de velocidad (4s a 30s por vuelta).
  - Simulación de sombra acústica de la cabeza (*Head Shadow Effect*) al transitar el sonido detrás del oyente.
  - Reverberación acústica binaural y ajuste de profundidad de sala sin modelos 3D invasivos.
- [x] **Temporizador de Apagado (Sleep Timer) con Fade-Out Suave**:
  - Configuración libre de minutos personalizados y chips rápidos (15m, 30m, 45m, 60m).
  - Contador regresivo en tiempo real (`mm:ss`) con opción de añadir +5 minutos.
  - Atenuación progresiva lineal del volumen en los últimos 10 segundos antes de pausar la reproducción.
- [x] **Control de Velocidad y Tono (Playback Parameters)**:
  - Modulación en tiempo real de velocidad (0.50x a 2.00x) y tono musical (Pitch Shift).
  - Botón de restablecimiento rápido a 1.0x.
- [x] **Reproducción Continua Automática, Transiciones y Fade-In de Volumen**:
  - Salto automático a la siguiente canción al terminar la pista actual sin pausas no deseadas.
  - Fundido cruzado ajustable con rampa de entrada suave (*fade-in*) que restaura fielmente el volumen original al pasar de pista.
  - Conmutador de reproducción Gapless continua sin silencios intermedios.
- [x] **Hoja Modal de Efectos en Now Playing (`AudioEffectsBottomSheet`)**:
  - Componente accesible desde la barra superior de Now Playing con indicador de insignia activa.

---

## 🛠️ Fase 4: Estabilidad Crítica, Diagnóstico Autónomo y UX Fluida (Completada ✅)

- [x] **Suite de Diagnóstico en Caliente "Aura Monitor"**:
  - Aplicación de depuración conectada pero con icono propio en el cajón de apps del teléfono móvil.
  - Captura y persistencia de excepciones fatales no controladas (`UncaughtExceptionHandler` -> CRASH).
  - Registro de incidentes clasificados por severidad (`CRASH`, `CRÍTICO`, `ERROR`, `WARNING`, `INFO`).
  - Telemetría técnica del teléfono: Fabricante, Modelo, Versión de Android / SDK API, CPU ABI, RAM y almacenamiento libre.
  - Visualizador de Stack Trace en crudo y exportación de informe completo al portapapeles.
- [x] **Integración de LeakCanary**:
  - Detección automática en tiempo real de fugas de memoria en builds de depuración.
- [x] **Ecualizador C++20 Integrado en Modal (Cero Apartados Aislados)**:
  - Eliminación de la pantalla completa separada para el ecualizador; integración nativa en pestaña modal accesible instantáneamente desde el Mini Reproductor y Now Playing.
- [x] **Estabilidad de Velocidad y Tono (Anti-Pausa Accidental)**:
  - Implementación de *throttling* y *debouncing* en `AuraAudioPlayer` para evitar saturación de `SonicAudioProcessor` en ExoPlayer.
  - Mecanismo de recuperación automática que reanuda la reproducción si el procesador de audio sufre una perturbación transitoria.
- [x] **Transición Fluida de Salida en Now Playing**:
  - Eliminación de capas negras residuales y parpadeos al cerrar o deslizar hacia abajo el reproductor mediante deslizamiento suave instantáneo.
- [x] **Video Canvas y Fondo Completo (3 Modos Seleccionables)**:
  - Soporte para asociar videos desde la galería a canciones individuales con Photo/Media Picker.
  - **3 Modos de Visualización**: Fondo Completo (video detrás de toda la pantalla con velo oscuro y carátula flotando al frente), Lienzo en Carátula (recuadro central 1:1) y Solo Carátula.
  - Selector modal interactivo accesible desde la barra superior y badge dinámico en la carátula.
  - Loops automáticos de Canvas (≤ 10s - 20s) en bucle continuo y videos sincronizados (> 20s) con selector de modo en edición.
  - **Armonización Cromática Reactiva**: Extracción dinámica de color desde fotogramas clave de video en tiempo real, evitando que el color de la carátula estática interfiera con el video.
  - Sincronización temporal reactiva con la música (`currentPositionMs` y `seekTo`) para videos largos.
  - Almacenamiento organizado en subcarpeta `videos/` con eliminación de archivos obsoletos.
- [x] **Sincronización Reactiva de Favoritos y Estabilidad en Inicio**:
  - Reflejo instantáneo del estado de favorito en el reproductor (corazón lleno en rojo `Color(0xFFEF4444)` al activar).
  - Estabilidad permanente en la sección "Populares en tu biblioteca", evitando que al pulsar el corazón se cambie la lista o se oculten otras canciones.
- [x] **Conversor Nativo "Video a Música" (Extracción 3 en 1)**:
  - Extracción directa de audio (`.m4a`) desde videos de la galería mediante demuxing sin recodificación en Android.
  - Captura y compresión automática de fotograma clave en WebP sin pérdida como carátula oficial.
  - Vinculación automática opcional como Video Canvas sincronizado o loop con inicio inmediato de reproducción.
- [x] **Descarga Directa desde TikTok y Enlaces Web (Música + Carátula + Video Canvas)**:
  - Descarga sin límites de duración para canciones completas, parodias y audios virales pegando el enlace.
  - Resolución inteligente sin marcas de agua con descarga de audio en alta fidelidad a `songs/`.
  - Captura y conversión de carátula oficial en WebP sin pérdida a `images/`.
  - Vinculación de Video Canvas continuo o sincronizado en `videos/` y reproducción instantánea en Now Playing.
- [x] **Soporte de Colores Dinámicos Material You (Android 12+)**:
  - Incorporación del tema Material You a las 5 opciones de personalización, adaptando los acentos primarios y secundarios a los colores del fondo de pantalla del sistema operativo.
- [x] **Blindaje Tipográfico Fijo contra Desbordamientos**:
  - Escala tipográfica estabilizada a valor cómodo (`fontScale = 1.0f`) garantizando que los ajustes globales de tamaño de letra de Android no desborden la interfaz.

---

## 🎧 Fase 5: Suite Acústica de Auriculares, Crossfeed C++20 y Ergonomía (Completada ✅)

- [x] **Filtro Crossfeed Acústico Nativo (ISO C++20)**:
  - Algoritmo acústico Bauer / Chu Moy para auriculares con filtro paso-bajos (~700 Hz) y retardo interaural (ITD).
  - Activación exclusiva cuando se detecta un auricular conectado (`isHeadphoneConnected`), en reposo para altavoces.
  - 3 niveles acústicos: Sutil (Bauer 4.5 dB), Moderado (Chu Moy Classic) e Intenso (Monitores de Estudio).
- [x] **Balance Estéreo Fino (Control Izquierda / Derecha L/R en Tiempo Real)**:
  - Compensación milimétrica de balance L/R con paneo suave y limitador suave anti-clipping en C++20.
  - Barra de ajuste en tiempo real en la pantalla completa Now Playing y en la hoja modal de efectos con botón de centrado.
- [x] **Protección contra Desconexiones ("Becoming Noisy" Guard)**:
  - Intercepción inmediata de `ACTION_AUDIO_BECOMING_NOISY` para pausar la música al desenchufar audífonos.
- [x] **Reanudación con Fade-In Suave (Volumen Progresivo)**:
  - Rampa suave de volumen de ~1 segundo al reanudar la reproducción con audífonos puestos para proteger los oídos.
- [x] **Memoria de Volumen Dedicada para Audífonos**:
  - Almacenamiento independiente de nivel de volumen para auriculares vs altavoz del dispositivo.
- [x] **Control Avanzado de Botones y Gestos de Auriculares (Headset Controls)**:
  - Detección de 1 pulsación, 2 pulsaciones, 3 pulsaciones y pulsación prolongada (hold) con mapeo libre personalizable.
- [x] **Pestaña Dedicada de "Auriculares" en Configuración**:
  - Navegación segmentada en 3 apartados: 1. Acústica & DSP, 2. Seguridad & Conexión, 3. Botones y Gestos.
- [x] **Notificación Nativa de Android y Servicio en Primer Plano (Media3 MediaSessionService)**:
  - Controlador multimedia nativo del sistema (System Media Controls) en Android 13, 14, 15+ con arte de carátula en alta definición y seekbar interactiva.
  - Compatibilidad retroactiva completa para Android 11/12 (Quick Settings) y Android 8/9/10 (`MediaStyle`).
  - Canal de notificación silencioso (`IMPORTANCE_LOW`) para transiciones limpias y libres de interrupciones sonoras.
  - Reproducción continua e indestructible en segundo plano con pantalla apagada.
- [x] **Descarga Directa desde YouTube y Video Web con Arquitectura Resiliente de 3 Niveles**:
  - **Motor Nativo InnerTube (`InnerTubeClient`)**: Clientes de baja fricción `ANDROID_VR` y `VISIONOS` para extracción ultrarrápida (<300ms) libre de `LOGIN_REQUIRED` o cifrado de firma `n-sig`.
  - **Bypass de Respaldo Invidious (`InvidiousStreamResolver`)**: Consulta en tiempo real a espejos de alta disponibilidad para resolver pistas protegidas por derechos o VEVO.
  - **Motor Headless WebView Reparado (`HeadlessWebViewExtractor`)**: Navegador efímero móvil (`m.youtube.com`) con bypass de gestos, timeout de 22s y captura en memoria.
  - **Selector Interactivo de Motor**: Permite al usuario alternar entre InnerTube y WebView en el diálogo con auto-fallback cruzado de 3 capas.
  - Adaptación visual dinámica al enlace pegado (Cyan/Magenta para TikTok y Rojo/Naranja para YouTube/Web).
  - Extracción automática de audio `.m4a`/`.mp3`, carátula WebP y Video Canvas sincronizado para Now Playing.

---

## 🎤 Fase 6: Visualizador Espectral, Intensidad Acústica C++20 y Letras Karaoke (Completada ✅)

- [x] **Visualizador Espectral y Armonización Dinámica de Video Canvas**:
  - Medición RMS en tiempo real y cálculo de envolvente espectral de 28 bandas directamente en el motor nativo (`getAudioIntensity()` y `getVisualizerBands()`).
  - Carátula central y Video Canvas despejados al 100% (eliminación de cápsulas flotantes superpuestas) con escala fija 1.0f para máxima nitidez sin movimientos no deseados.
  - Sombra y halo lumínico ambiental superior modulando brillo y color en intervalos de 2.5s según las escenas del video con fundido suave (`tween(1200)`).
  - Visualizador de ondas sonoras `AudioVisualizer` alimentado por las bandas calculadas en C++.
- [x] **Mini Reproductor Tintado y Atajos Equilibrados**:
  - Fondo del mini reproductor completamente tintado y degradado con los colores extraídos de la pista o video actual.
  - Botonera inferior de Now Playing rediseñada en 3 módulos simétricos con área táctil superior a 48dp, resolviendo el corte vertical en el botón de cola.
  - Desbloqueo total de duración en TikTok mediante demuxing directo de audio sin recodificación para pistas de hasta 1 hora.
- [x] **Letras Sincronizadas (.LRC) Estilo Karaoke con Descarga Automática**:
  - Descarga automática libre desde el servicio público **LRCLIB** al iniciar canciones sin letra, sin registro ni claves externas.
  - Persistencia local en la subcarpeta estructurada `lyrics/track_{id}.lrc`.
  - Tarjeta interactiva `NowPlayingLyricsCard` con desplazamiento suave automático (*auto-scroll*) para centrar la frase activa.
  - Resaltado neón de alta visibilidad con tipografía ampliada (`19.sp`, negrita extra) para el verso actual y atenuación de líneas pasadas.
  - Salto interactivo a la marca de tiempo (*Seek*) al tocar cualquier verso.
  - Diálogo para carga o edición manual de letras en formato `.lrc` o texto plano.

- [x] **Integración Inteligente 'Abrir con...' y 'Compartir con...' (Puente con SnapTube, Gestores de Descarga y Navegadores)**:
  - Detección automática y triaje certero de medios (`IncomingMediaHandler`) combinando MIME type, extensión de archivo y análisis de cabeceras en `MediaMetadataRetriever`.
  - Para audios (`audio/*`): copia segura a `songs/` para evitar pérdidas si la app externa borra caché o revoca permisos, inserción en Room y reproducción inmediata con Now Playing expandido y búsqueda de letras LRCLIB.
  - Para videos (`video/*`): apertura inmediata de `VideoToMusicDialog` para conversión 3 en 1 (.m4a, carátula WebP y Video Canvas sincronizado).
  - Para enlaces web (`text/plain` / URL): apertura directa de `DownloadFromLinkDialog` con auto-resolución del título, autor y carátula.
  - Soporte `singleTop` en `MainActivity` y manejo fluido tanto en arranque en frío como en segundo plano vía `onNewIntent`.
- [x] **Eliminación Inteligente de Silencios al Inicio y Final (`AudioSilenceTrimmer`)**:
  - Interruptor interactivo previo a cada importación (archivos, carpetas, Video a Música, descargas de TikTok/YouTube y recepción con 'Abrir con...').
  - Detección acústica de silencios iniciales y finales por umbral RMS (`-42 dB`) decodificando únicamente las colas inicial y final.
  - Recorte sin pérdida por *Direct Stream Copy* en contenedores compatibles y configuración de recorte exacto con `MediaItem.ClippingConfiguration`.
- [x] **Repetidor de Segmento A-B (A-B Loop) y Ergonomía Visual**:
  - Barra compacta `[A]`, `[B]` y limpiar (`×`) integrada junto al progreso en *Now Playing* con marcador visual sobre el Seekbar.
  - Panel detallado en la hoja modal de efectos con ajuste fino de ±1 segundo (`-1s` / `+1s`) e interruptor de bucle.
  - Limpieza de la barra superior de *Now Playing* eliminando el texto redundante "REPRODUCIENDO AURA / álbum" para dar mayor amplitud a los iconos de acción.
  - Desplazamiento horizontal continuo tipo marquesina (`basicMarquee`) para títulos largos en *Now Playing*, *Mini Reproductor* y canción activa en listas y cola.
  - Modal de descarga (`DownloadFromLinkDialog`) completamente deslizable verticalmente (`verticalScroll`) para acceso total en pantallas compactas al descargar desde YouTube o TikTok.
  - Corrección definitiva del Reverb procesándolo 100% en el motor nativo C++20 (`ReverbProcessor`) sin bloqueo ni silenciamiento del driver LVREV de Android.
  - Ampliación de Velocidad de Música y Velocidad de Voz / Tono (`Pitch`) hasta `2.0x` con botones rápidos (`0.8x`, `1.0x`, `1.25x`, `1.5x`, `2.0x`) en ambos controles.

- [x] **Garantía de Carátulas Oficiales en Descarga WebView y Fallback en Cascada**:
  - Corrección de miniaturas en el motor WebView mediante extracción de metadatos en el DOM y descarga en cascada multinivel (`maxresdefault.jpg` -> `hqdefault.jpg` -> `mqdefault.jpg` -> `i.ytimg.com` -> fotograma clave de video).
  - Elimina al 100% las canciones sin carátula al descargar mediante el motor WebView en YouTube.
- [x] **Importador de Letras (.LRC y .TXT) desde el Celular y Auto-Detección Local**:
  - Botón integrado en la tarjeta Karaoke y en estado vacío para importar archivos `.lrc` y `.txt` descargados en el teléfono mediante SAF (`OpenDocument`).
  - Detección y asociación automática de archivos de letras hermanos (`.lrc`/`.txt` con el mismo nombre) al importar música o carpetas desde el teléfono.
  - Soporte de visualización para texto plano `.txt` con desplazamiento continuo y adaptación tipográfica.
- [x] **Suite de Rendimiento, RAM Detallada e Inspector de Hilos en Aura Monitor**:
  - Navegación modular por pestañas: *Incidentes & Logs* y *Rendimiento & Hilos*.
  - Monitoreo en vivo de RAM segmentada: Java Heap (VM), Native Heap (C++20 DSP y CMake), Gráficos/Shaders (Compose y WebP) y PSS Total.
  - Telemetría de CPU del proceso (%), núcleos activos, FPS de UI y estado térmico del procesador.
  - Inspector de hilos en vivo (`Thread.getAllStackTraces()`) con clasificación por categorías (Audio, C++ DSP, UI, Corrutinas), estado (`RUNNABLE`, `TIMED_WAITING`), trazas de pila completas y copia al portapapeles.
- [x] **Video Canvas 100% Despejado, Sincronización de Velocidad y Armonización Cromática Instantánea**:
  - Eliminación definitiva del badge o indicador "VIDEO SYNC" / "LOOP CANVAS" sobre la carátula para una visualización sin obstrucciones.
  - Extracción cromática exacta con `MediaMetadataRetriever.OPTION_CLOSEST` y `MediaMetadataRetriever` persistente, erradicando el retraso de 2.5s de los Keyframes y respondiendo de inmediato a cada escena con `tween(180)`.
  - Eliminación total de fondos negros y parpadeos al abrir Now Playing o el Mini Reproductor mediante `seekTo` previo a `prepare()`, obturador transparente y placeholder de carátula (`placeholderTrack`) con fundido en `onRenderedFirstFrame()`.
  - Soporte de Video Canvas miniatura en el Mini Reproductor flotante configurable por el usuario desde Ajustes.
  - Sincronización milimétrica de velocidad de reproducción (0.50x a 2.00x) entre la música y el video de fondo.
  - Erradicación de la fuga de memoria en `AuraMediaPlaybackService` (`ResourcesImpl.mAppContext`) detectada por LeakCanary.
- [x] **Búsqueda Interactiva de Letras, Elección de Versiones y Recomendación de Lírica Oficial**:
  - Diálogo interactivo `SearchLyricsDialog` donde el usuario puede escribir y modificar el nombre de la canción y el artista libremente.
  - Algoritmo de priorización en `LyricsManager` que consulta endpoints canónicos (`/api/get`) y de búsqueda (`/api/search`) en LRCLIB para identificar la versión oficial.
  - Posicionamiento estricto de la Lírica Oficial en primera posición (#1) con insignia luminosa `⭐ OFICIAL / RECOMENDADA` y borde de neón.
  - Lista completa de opciones comunitarias con comparador de formato (Sincronizada vs Texto plano), duración y previsualización de versos.
  - Integración accesible tanto desde el botón de búsqueda en la tarjeta de Karaoke como desde el estado de canción sin letra.

- [x] **Integración Completa de FFmpeg Puro y Entorno Python con yt-dlp en el APK Final**:
  - `FFmpegNativeEngine`: Motor de procesamiento multimedia a nivel nativo/CLI sin wrappers obsoletos, con binario ejecutable `libffmpeg.so` real asegurado en `app/build.gradle.kts` (`provisionNativeDeps` + `native_ffmpeg_launcher.c` con puente NDK `dlopen`/`dlsym` hacia `libffmpegkit.so`/`libavcodec.so`/`libavfilter.so`) y paquete dinámico depurado (`libffmpeg.zip.so`) empaquetados en `jniLibs/` para todas las arquitecturas (`arm64-v8a`, `armeabi-v7a`, `x86_64`, `x86`), optimizado para extracción de audio, transcodificación a AAC/MP3 y fusión DASH `-c copy`.
  - **Bucle Infinito sin Cortes (Seamless Loop con Crossfade) & Efecto Boomerang / Ping-Pong (`reverse` + `concat`)**: Creación automatizada de loops de Video Canvas (≤ 20s) con selector interactivo entre fundido continuo mediante `xfade` y **Efecto Boomerang (`reverse` + `concat=n=2:v=1:a=0`)** en *Editar Canción*, *Video a Música* y *Descargar desde Enlace*, logrando repetición cíclica continua de ida y vuelta sin saltos en ExoPlayer.
  - **Optimización de Fotogramas Clave (Keyframes / GOP Corto a 30fps)**: Reestructuración de videos largos sincronizados con inserción de I-frames cada 1 segundo (GOP=30), eliminando audio residual y aplicando `-movflags +faststart` para saltos temporales instantáneos (0ms) en Now Playing y Mini Reproductor.
  - `YtDlpNativeEngine`: Runtime de CPython nativo (`libpython.so`) con entorno optimizado (`libpython.zip.so`) y QuickJS (`libqjs.so`) empaquetados en el APK, con copia base oficial en `nativeLibraryDir/libytdlp.zip.so` para funcionamiento inmediato sin duplicación en `assets/`.
  - `YtDlpAutoUpdater`: Sistema de actualización OTA en caliente que consulta GitHub Releases y descarga la versión más reciente del extractor directamente en `files/bin/yt-dlp` sin forzar al usuario a esperar una nueva versión del APK en Uptodown.
  - **Acelerador de Descarga por Bloques (Chunked Range Download)**: Erradicación del estrangulamiento de ~63 KB/s de Google Video mediante fragmentación de rangos HTTP en bloques de 2.5 MB, alcanzando velocidades de descarga de 10 a 40 MB/s.
  - **Resolución 480p Estricta por Defecto para Video Canvas**: Configuración y filtrado selectivo en `yt-dlp`, `InnerTube` e `Invidious` fijando por defecto la descarga de video a 480p (`height=480`) con vinculación automática garantizada al Video Canvas de fondo.
  - Pantalla dedicada en *Ajustes > Motores Nativos & Diagnóstico* con información en vivo de FFmpeg y botón interactivo para actualizar `yt-dlp` en segundo plano.
- [x] **Transparencia Total y Gestor de Medios Almacenados en Ajustes (`StoredMediaSettingsTab`)**:
  - Nueva pestaña "Medios" en la pantalla de Ajustes con desglose exhaustivo de carátulas WebP y Videos Canvas MP4 persistidos en disco (`images/` y `videos/`).
  - Muestra la canción asociada, tamaño exacto del archivo (KB/MB) y botones individuales con confirmación para borrar la carátula o el video de cualquier pista, liberando espacio físico de inmediato.
- [x] **Miniaturas de Carátula en la Cola de Reproducción (NowPlayingQueueSheet)**:
  - Integración de carátulas en alta resolución (`ArtworkImage` de 42dp con bordes redondeados) para cada pista en la lista en espera, permitiendo identificar canciones al instante visualmente.
- [x] **Consistencia Geométrica y Pulido de Diseño en Letras / Karaoke**:
  - Homogeneización de dimensiones de `NowPlayingLyricsCard` con la carátula (`fillMaxWidth(0.86f).aspectRatio(1f)` con radio de 26dp), eliminando saltos o desalineaciones visuales al alternar entre carátula y letras.
  - Resaltado activo tipo píldora para la frase en reproducción y rediseño de insignias en `SearchLyricsDialog` para erradicar cualquier desbordamiento o colisión de texto.
- [x] **Persistencia Permanente de Configuración de Color y Material You**:
  - Almacenamiento y restauración automática en `SharedPreferences` del tema visual seleccionado (`AuraTheme`, incluyendo *Material You*), el estado de *Aura Dinámica de Carátula* y el modo de *Video Canvas*, garantizando que nunca se reinicien al cerrar y volver a entrar a la app.
- [x] **Portadas Personalizadas en Playlists y Collage Dinámico de 1 a 4 Canciones (`PlaylistCoverCollage`)**:
  - Soporte para elegir una imagen personalizada desde la galería (con compresión WebP sin pérdida en `images/` y migración Room `v2 -> v3`) al crear o editar cualquier Playlist.
  - Generador automático de collage adaptativo cuando la Playlist no tiene imagen propia: 1 foto (1 canción), collage de 2 fotos (2 canciones), collage de 3 fotos (3 canciones) y cuadrícula 2x2 de 4 fotos (4 o más canciones).
- [x] **Navegación a Vista de Canciones en Artistas y Álbumes**:
  - Al pulsar sobre un Artista o un Álbum en la Biblioteca, se abre la vista detallada con todas sus canciones listadas (igual que en las Playlists) en lugar de reproducir la primera pista de inmediato.
- [x] **Transición Fluida entre Videos sin Residuos y Reencuadre Inteligente 16:9 / 9:16 con FFmpeg**:
  - Erradicación definitiva de la persistencia del video anterior al terminar la canción o avanzar de pista en Now Playing y Mini Reproductor mediante aislamiento con claves `key(track.id, track.videoUri)`, bloque `update` en `AndroidView` y reseteo reactivo de primer fotograma.
  - Transición suave de fundido cruzado (*crossfade*) entre pistas sobre la carátula oficial de respaldo, garantizando cero retrasos o imágenes congeladas.
  - Detección de relación de aspecto de video (`probeVideoDimensions` / `onVideoSizeChanged`) para videos horizontales (16:9) vs verticales (9:16).
  - Generación de lienzo vertical cinemático 9:16 en FFmpeg (`createVerticalCanvasFromHorizontalVideo`) con video original centrado sin recortes de rostros y fondo ambiental difuminado (`boxblur=16:2`).
  - Adaptación visual en tiempo real en `BackgroundVideoPlayer` con `RESIZE_MODE_FIT` para videos horizontales en Fondo Completo, e indicador de aspecto en Ajustes > Medios.
- [x] **Limpieza Atómica de Buffer (Buffer Flushing) en C++20 y Media3**:
  - Purgado atómico de acumuladores y líneas de retardo (`flushDspBuffers`) en cambios de canción (`playTrack`), saltos de barra (`seekTo`), pausas (`pause`), fin de pista y cierre del reproductor (`release`).
  - Erradica de forma definitiva ruidos transitorios, "pops" o chasquidos digitales y colas de eco residuales de reverb de la pista previa.
  - Sincronización transparente con el ciclo de vida de Media3 mediante `onFlush()` en `NativeAudioProcessor`.
- [x] **Modularización y Partición de Archivos Gigantes**:
  - Reestructuración del núcleo C++20 (`auramusic_dsp.h`) en cabeceras modulares especializadas: `dsp_filters.h`, `dsp_spatial.h`, `dsp_crossfeed.h` y `dsp_reverb.h`.
  - Desacoplamiento de `MusicViewModel.kt` mediante el patrón de Coordinadores en `viewmodel/delegates/`: `LyricsCoordinator`, `IncomingMediaCoordinator` y `HeadphoneSettingsCoordinator`, reduciendo la complejidad ciclomática y manteniendo intacta la API pública.
- [x] **Blindaje Criptográfico de Seguridad y Aprovisionamiento Nativo Puro**:
  - Declaración obligatoria de los permisos `android.permission.INTERNET` y `ACCESS_NETWORK_STATE` en `AndroidManifest.xml`.
  - Protección criptográfica contra Ejecución Remota de Código (RCE) en `YtDlpAutoUpdater` mediante verificación de hash `SHA-256` contra `SHA2-256SUMS` oficial de GitHub Releases y validación de host.
  - Neutralización de vulnerabilidad Zip Slip (Path Traversal) con validación estricta de rutas canónicas en `FFmpegNativeEngine` y `YtDlpNativeEngine`.
  - Protección contra inyección de argumentos (`--`) en procesos CLI y sanitización de intents externos en `DebugMonitorActivity`.
  - **Consolidación de Certificados TLS para Android 14+**: Erradicación del error `[SSL: CERTIFICATE_VERIFY_FAILED: unable to get local issuer certificate]` mediante volcador automático de certificados CA de Conscrypt APEX (`/apex/com.android.conscrypt/cacerts/`) y KeyStore hacia `usr/etc/tls/cert.pem` con reintento auto-sanador en `YtDlpNativeEngine`.
  - Eliminación total de archivos `.sh` y migración del 100% de la lógica de aprovisionamiento y compilación nativa a `app/build.gradle.kts` (`provisionNativeDeps` y `ensureDebugKeystore`) y `app/src/main/cpp/` (`native_python_launcher.c`, `native_ffmpeg_launcher.c`, QuickJS C99 puro), aprovisionando CPython 3.11 real multi-ABI, FFmpeg nativo puro, QuickJS C99 y `yt-dlp` sin wrappers ni llamadas a `sh`.
- [x] **Compresión Ligera en FFmpeg: Pista de Audio Eliminada (`-an`) y Purga de Metadatos (`-map_metadata -1`)**:
  - Aplicación automática de `-an` en la tubería de Video Canvas de FFmpeg para descartar pistas de audio duplicadas, ahorrando de 5 a 20 MB por canción.
  - Purga de metadatos innecesarios (`-map_metadata -1`) en el contenedor MP4.
  - Implementación de `stripAudioAndMetadata` (`-c:v copy -an -map_metadata -1 -movflags +faststart`) como remux ultrarrápido y seguro de respaldo.
- [x] **Pantallas Independientes de Bienvenida, Inducción y Disclaimer de Almacenamiento (`OnboardingScreen`)**:
  - Flujo modular de bienvenida en 3 etapas con estética Dark Luxury Neo-Glass: Bienvenida y filosofía offline, resumen de lo que ofrecemos (C++20 DSP, Video Canvas, Karaoke LRCLIB, Video a Música) y aviso importante de almacenamiento.
  - Disclaimer transparente informando que los Video Canvas se almacenan en alta resolución en el teléfono y cómo gestionarlos desde Ajustes > Medios para liberar espacio en MB.
  - Persistencia con `pref_onboarding_completed`, navegación fluida en `MainActivity` sin barras inferiores intrusivas y botón de re-apertura en Ajustes.
- [x] **Encuadre Personalizable de Video de Fondo (Rellenar vs Adaptado), Descarga en Segundo Plano con Notificación Nativa y Pulido Visual**:
  - Elección libre entre **Fondo Completo • Rellenar (Recortar)** (`RESIZE_MODE_ZOOM`, 100% pantalla vertical sin divisiones centrales) y **Fondo Completo • Adaptado Horizontal** (`RESIZE_MODE_FIT`, cuadro 16:9 completo sin recortar caras) tanto en los diálogos de descarga/conversión/edición como en tiempo real desde *Now Playing*.
  - Servicio en primer plano `AuraDownloadService` (`foregroundServiceType="dataSync"`) que mantiene activas las descargas y el procesamiento FFmpeg al salir de la app, mostrando progreso en vivo en la barra de notificaciones de Android y avisando al terminar (reproduciendo la pista al tocar la notificación si el usuario estaba fuera de la app).
  - Eliminación total de la pantalla aislada redundante `EqualizerScreen.kt` y reemplazo del acceso en la cuadrícula de *Inicio* por la **Playlist más escuchada** del usuario (`totalPlays`).
  - Corrección de maquetación en *Ajustes > Medios* (`StoredMediaSettingsTab`), acotado de marquesinas con `clipToBounds()` y recorte automático de franjas negras (`letterbox` 4:3) en miniaturas de YouTube (`DeletterboxTransformation` y `removeHorizontalLetterboxBars`).
- [x] **Verificación y Actualización Transparente de Paquetes en Segundo Plano, Audio 16D Multi-Órbita y Clarificador de Voces HD en C++20**:
  - **Ciclo de Verificación al Iniciar (`YtDlpAutoUpdater`, `PackageUpdateState` & `PackageUpdateBanner`)**: Comprobación automática en segundo plano al abrir la app con notificación nativa en la barra de estado (*"Verificando paquetes necesarios..."*) y banner superior compacto no intrusivo.
  - **Descarga con Barra de Progreso, Staging Atómico y Reinicio Asistido**: Notificación nativa e indicador interno con barra de progreso en vivo (*"Descargando actualización de paquetes"*), validación SHA-256 sobre `yt-dlp.staged`, bloqueo temporal preventivo de descargas por `yt-dlp` hasta aplicar los cambios y botón rápido **"Actualizar y Reiniciar"** (o aplicación automática al salir y reabrir la app).
  - **Motor C++20 de Audio 16D Multi-Órbita (`EightDProcessor::set16DMode`)**: Doble órbita binaural contra-rotatoria en C++20 con división espectral (bajos en órbita interna y voces/agudos en órbita figura-8 con micro-retardo Haas), integrada con selector directo 8D / 16D libre de logotipos o animaciones decorativas.
  - **Motor C++20 Clarificador de Voces HD (`VocalClarityProcessor` en `dsp_filters.h`)**: Procesamiento Mid-Side en 64 bits con aislamiento del canal vocal central, atenuación de turbidez a 180 Hz y realce biquad de presencia (2.8 kHz) y articulación (5.5 kHz), ubicado estratégicamente en las pestañas *Ecualizador* y *Velocidad/Voz*.
- [x] **Mixtape Maker / Fusión de Canciones con Crossfade Continuo en FFmpeg, Capítulos Reactivos de Carátulas/Videos y Letras LRC**:
  - **Fusión Nativa en un Solo Archivo Continuo (.m4a) con FFmpeg (`MixtapeEngine`)**: Unión de múltiples pistas con fundido cruzado (*acrossfade* en FFmpeg) y selector de duración de transición (3s, 5s, 8s, 10s) con normalización acústica previa a 44.1 kHz estéreo para cero chasquidos o desincronizaciones.
  - **Capítulos Reactivos para Carátula y Video Canvas en Tiempo Real**: Sistema de marcas temporales exactas (`metadata/mixtape_{id}.json` y `MixtapeChapter`) que conmuta de forma reactiva el título, artista, carátula oficial WebP y Video Canvas de la canción correspondiente en *Now Playing* y en el *Mini Reproductor* al transcurrir el audio o al hacer seek.
  - **Sincronización Cromática Continua**: Extracción dinámica de color de fondo y ambient glow adaptada a cada capítulo activo de la mezcla en tiempo real.
  - **Karaoke con Letras LRC Continuas Concatenadas**: Concatenación automática de las letras sincronizadas (.lrc) sumando el offset temporal acumulado de cada capítulo, permitiendo auto-scroll continuo y karaoke fluido a lo largo de todo el mix continuo.
  - **Portada Oficial en Collage WebP**: Generación automática de portada en collage de 1 a 4 fotos comprimida en WebP Lossless en `images/`, registrándose como pista completa en la base de datos bajo el álbum *"Aura Mixtapes"*.
- [x] **Funcionalidades de Audio y Karaoke de Nivel Spotify**:
  - **Normalización de Volumen Inteligente (Loudness Normalizer Spotify / EBU R128 en C++20 `VolumeNormalizerProcessor`)**: Nivelación dinámica de sonoridad acústica entre pistas de diferentes épocas y fuentes (YouTube, TikTok, audios locales) en 64 bits con limitador transparente anti-clipping y 3 modos seleccionables (*Sutil -18 LUFS*, *Estándar Spotify -14 LUFS*, *Alto -11 LUFS*).
  - **Automix Inteligente & Crossfade DJ con Curva de Ecualización en X (`DjAutomixFilter` en C++20)**: Transición fluida de discoteca entre canciones con detección acústica de outro (< 0.07f) para omitir silencios vacíos y curva paramétrica de ecualización en X que atenúa subgraves (< 120 Hz) y agudos de la pista que finaliza, eliminando choques de bajos (*bass clashing*) con la pista entrante.
  - **Modo Karaoke a Pantalla Completa Inmersivo (`FullScreenLyricsScreen`)**: Experiencia estilo Spotify / Apple Music Sing con fondo ambiental dinámico que respira con el audio en C++20, tipografía grande de hasta 26sp con resaltado neón, auto-scroll interactivo con botón flotante *"Sincronizar con audio"* y barra de transporte flotante inferior con minicarátula, marquesina fluida y seekbar.
  - **Selector de Diseños del Reproductor y Modo Cinemático Canvas Estilo Spotify (`NowPlayingDesignMode` & `NowPlayingCinematicLayout`)**: Elección interactiva entre *Modo Clásico (Carátula Central)*, *Modo Cinemático Canvas* (video de fondo completo despejado, minicarátula de 54dp, frase lírica flotante, controles en el tercio inferior con Play/Pausa de 64dp y acceso a vista previa de letras) y *Automático Inteligente*, persistido en preferencias y accesible desde Now Playing y Ajustes.

- [x] **Selector Clásico Circular ("Bolita"), Reactividad Cromática en Modo Cinemático Canvas (Spotify) y Pulido de Karaoke**:
  - **Bolita Clásica en Barra de Reproducción**: Sustitución del indicador vertical tipo mango/palo de M3 por un selector clásico circular ("bolita") de 14dp sólido en blanco puro, con halo reactivo de 18dp modulado por `animatedPrimary` y elevación con sombra tanto en *Modo Clásico* (`NowPlayingPlaybackControls`), *Modo Cinemático Canvas* (`NowPlayingCinematicLayout`), *Karaoke Pantalla Completa* (`FullScreenLyricsScreen`) como en *Balance Estéreo* (`NowPlayingBalanceBar`).
  - **Reactividad Cromática Completa al Video Canvas en Modo Cinemático (Spotify)**: Viñeta atmosférica ambiental superior e inferior modulada reactivamente por los colores dinámicos del video (`animatedPrimary` y `animatedSecondary`) y la intensidad acústica C++20 (`audioIntensity`), seekbar interactiva iluminada con el acento del video, halo reactivo pulsante en el botón Play/Pausa central de 64dp, píldora de letra flotante con borde neón y tarjeta inferior "Vista previa de la letra" armonizada.
  - **Solución al Desbordamiento de Cabecera en Karaoke Pantalla Completa**: Cápsula compacta "KARAOKE" (11sp) con icono de micrófono y redimensionamiento proporcional a 40dp de los botones de acción (Buscar versión, Importar archivo SAF y Editar letra), garantizando que los 3 botones encajen perfectamente sin colisiones ni cortes laterales en cualquier resolución de pantalla.
- [x] **Renombrado a "Ajustes" y Navegación por Menús Independientes a Pantalla Completa (`SettingsScreen` & `SettingsSubMenuScreen`)**:
  - Renombrado a **"Ajustes"** en la barra de navegación inferior (`BottomNavBar`) y eliminación de la barra de pestañas superior redundante (`Ajustes / Auriculares / Medios`) en `SettingsScreen`.
  - Reestructuración de todos los apartados (*Diseño del Reproductor*, *Aura Dinámica & Video*, *Paleta Base Predeterminada*, *Auriculares & Acústica DSP*, *Medios & Almacenamiento*, *Motores Nativos & Diagnóstico* y *Bienvenida*) en tarjetas de navegación unificadas con indicador `>`.
  - Reemplazo del selector modal emergente en Ajustes por **pantallas independientes a pantalla completa** (`SettingsSubMenuScreen` y `PlayerDesignSettingsContent`) con transiciones horizontales fluidas, cabecera de retroceso y soporte de `BackHandler`.

---

## 🔊 Fase 7: Modo Bit-Perfect, AAudio Ultra-Baja Latencia, Decodificación DSD/APE/Chiptune, Widgets y Android Auto (Completada ✅)

- [x] **Integración con Google Oboe / AAudio y Modo Bit-Perfect Direct Bypass (`dsp_bitperfect.h`)**:
  - Motor nativo en ISO C++20 con puente directo a la API `AAudio` del NDK (`AAudioStreamBuilder`) en modo de rendimiento `AAUDIO_PERFORMANCE_MODE_LOW_LATENCY` y uso compartido exclusivo/adaptativo para DACs USB y auriculares Hi-Res.
  - **Modo Bit-Perfect Direct Bypass (`BitPerfectController`)**: Omite toda alteración matemática de fase o ganancia (EQ de 10 bandas, Bass Boost, Reverb, 8D/16D y Crossfeed) entregando una copia 1:1 bit a bit del flujo PCM original con telemetría en vivo (rango dinámico en dB, picos de señal y latencia en milisegundos).
  - Presets de resolución Hi-Res seleccionables en *Ajustes > Auriculares & Acústica DSP*: *Nativo 1:1 (Sin Resampling)*, *Hi-Res 96 kHz / 24-bit* y *Ultra Hi-Res 192 kHz / 32-bit Float*, además de modo exclusivo para DAC USB externo.
  - Ficha técnica de pista (`AudioSpecsDialog`) enriquecida con diagnóstico de hardware AAudio, estado Bit-Perfect, tasa de muestreo nativa y latencia real en ms.
- [x] **Decodificación Nativa de Formatos Especiales (`SpecialAudioFormatDecoder.kt`)**:
  - Soporte integral en `SafTrackImporter`, `IncomingMediaHandler`, `AudioMetadataParser` y `Track.formatBadge()` para archivos audiófilos y retro: **DSD** (`.dsf`, `.dff`), **Monkey's Audio** (`.ape`), **WavPack** (`.wv`), **ALAC / AIFF** (`.alac`, `.aiff`), **Musepack** (`.mpc`) y módulos **Chiptune / Tracker** (`.mod`, `.xm`, `.it`, `.s3m`).
  - Decodificación nativa automática en segundo plano mediante `FFmpegNativeEngine` (DoP / DSD64/128, `libmodplug`/tracker y APE) hacia contenedor maestro sin pérdida (`.wav` / `.m4a` Hi-Res) en `songs/` cuando el extractor base del sistema requiere transcodificación transparente.
- [x] **Sistema de 2 Widgets Interactivos Adaptativos con Color de Carátula, Reanudación en Segundo Plano y Apartado "Widget" en Ajustes (`AuraMusicWidgetProvider` & `AuraLibraryWidgetProvider`)**:
  - **Reacción Cromática a la Imagen (`WidgetStateStore` & `WidgetArtworkRenderer`)**: Extracción automática de la paleta vibrante y secundaria desde la carátula WebP de la canción en curso (o su arte procedural), generando al vuelo un fondo Neo-Glass con gradiente e iluminación ambiental sin bloquear el hilo principal.
  - **Adaptación Multi-Tamaño al Estirar (`onAppWidgetOptionsChanged`)**: El Widget principal conmuta automáticamente entre 3 diseños según cómo lo estire el usuario en su pantalla de inicio: *Compacto (4x1)* con botón de Favorito ❤️, *Mediano (4x2)* con barra de progreso sincronizada y tiempos `mm:ss`, y *Expandido (4x3)* con carátula grande de estudio y botonera completa.
  - **Reanudación de Música en Segundo Plano (`WidgetPlaybackHeadlessController`)**: Persistencia del último `trackId`, `positionMs` y estado de reproducción para que al pulsar *Play*, *Siguiente*, *Anterior* o *Favorito* con la app cerrada, el motor despierte silenciosamente en segundo plano desde el segundo exacto donde quedó.
  - **Segundo Widget Independiente en el Selector de Android (`AuraLibraryWidgetProvider`)**: Widget de buen tamaño con cabecera de reproducción activa y cuadrícula 2x2 que muestra las **4 canciones más escuchadas** o las **4 Playlists principales** (con soporte de collage 2x2 de hasta 4 fotos) para iniciar su reproducción al instante.
  - **Nuevo Apartado "Widget" en Ajustes (`WidgetSettingsContent.kt`)**: Pantalla completa dedicada en Ajustes con vista previa interactiva en vivo de ambos widgets, selector de modo (*4 Canciones Más Escuchadas* vs *4 Playlists*), interruptor de color dinámico de la imagen, control de intensidad cromática (30% - 100%) e interruptor de barra de progreso.
  - Descriptor oficial `automotive_app_desc.xml` registrado en `AndroidManifest.xml` habilitando integración multimedia con consolas de vehículos compatibles con **Android Auto**.
- [x] **Pipeline de Compilación y Distribución APK Beta (`Aura Beta` • Codename `Nebula` • `v0.2.0-beta-1a`)**:
  - Configuración dedicada del tipo de compilación `beta` con identificador `com.auramusic.beta` (almacenamiento en `Android/data/com.auramusic.beta/files/`), nombre en launcher **`Aura Beta`**, codename **`Nebula`** y código estratégico **`NEBULA-00200A`** (`versionCode = 100200`).
  - Eliminación total de herramientas de depuración y pruebas en el APK Beta (`DebugMonitorActivity` removido mediante `src/beta/AndroidManifest.xml`, `BuildConfig.ENABLE_DEBUG_MONITOR = false`, `BuildConfig.ENABLE_DEMO_TRACKS = false` ocultando la generación de audios de prueba Synthwave y exclusión de `LeakCanary`), manteniendo 100% operativo el actualizador OTA de `yt-dlp`.
    - Cierre automático del modal de inserción de enlaces (`DownloadFromLinkDialog`) recién al completarse la descarga (mostrando en vivo el progreso en `DownloadProgressStatusCard`, o permitiendo ocultarlo manualmente con la `X` / "Continuar en segundo plano") para pasar directamente a la reproducción.
    - Perfeccionamiento del selector circular clásico ("bolita") en todas las barras de progreso (`Slider`) con renderizado de `track` continuo personalizado de 4dp, eliminando los huecos laterales (`thumbTrackGapSize`) y el punto final (`stopIndicator`) por defecto de Material 3.
    - Aviso interactivo de descubrimiento (`SettingsDiscoveryBanner` e insignia en `BottomNavBar`) al entrar por primera vez a la app sin haber visitado aún la pestaña de **Ajustes**, invitando al usuario a explorar las opciones avanzadas de configuración y desapareciendo automáticamente al entrar a Ajustes.
    - Generación de **3 APKs exclusivos para móviles** (`arm64-v8a`, `armeabi-v7a` y `universal` 32+64 bits) eliminando las arquitecturas de PC (`x86` / `x86_64`).
    - Flujo de GitHub Actions `.github/workflows/build-beta-apk.yml` **100% sin caché**, firmado con credenciales de GitHub Secrets (`BETA_KEYSTORE_BASE64`, `BETA_KEYSTORE_PASSWORD`, `BETA_KEY_ALIAS`, `BETA_KEY_PASSWORD`).
    - Publicación condicional inteligente: si se lanza manualmente (`workflow_dispatch`) entrega los 3 APKs solo en *Artifacts*; si se lanza mediante un **Pre-Release con tag `-beta`** adjunta los 3 APKs a los *Assets* del Pre-Release junto con el documento **`chanelog-beta.md`**.
    - **Actualizador Automático de Versiones APK (`AppReleaseUpdater`, `AppUpdateDialog` & `AppReleaseUpdateSettingsCard`)**: Comparador semántico de tags dinámicos (`v0.1.0-beta.1a` → `v0.1.1-beta-1a` → `v0.2.0-beta.1m`), selección automática del APK según la arquitectura del móvil (`arm64-v8a`, `armeabi-v7a` o `universal`), verificación SHA-256 contra `SHA256SUMS.txt`, visualización de `chanelog-beta.md` e instalación mediante `FileProvider` conservando todos los datos en `Android/data/com.auramusic.beta/`.
    - **Optimización Quirúrgica de Tamaño de APK y Almacenamiento Instalado**:
      - Re-compresión con **Deflate Nivel 9 (`Deflater.BEST_COMPRESSION`)** tanto en `stdlib.zip` (`libpython.zip.so`) como en `yt-dlp` (`libytdlp.zip.so`).
      - **Poda Segura de `stdlib.zip` y Módulos C**: Poda de paquetes de escritorio, servidores de correo antiguos, profilers y suites de pruebas de la librería estándar de Python (`test`, `unittest`, `tkinter`, `idlelib`, `turtledemo`, `pydoc_data`, `distutils`, `lib2to3`, `ensurepip`, `venv`, `curses`, `dbm`, `msilib`, `doctest`, `pdb`, `_pydecimal`, `pydoc`, `mailbox`, `pickletools`, `difflib`, `smtpd`, `smtplib`, `imaplib`, `poplib`, `nntplib`, `ftplib`, `telnetlib`, `cProfile`, `pstats`, `trace`, `wsgiref`, `xmlrpc`), conservando intactos `quopri`, `uu`, `imghdr`, `tarfile`, `code`, `bdb` y `encodings/` requeridos por `yt-dlp` y `urllib`, y poda de módulos C nativos que `yt-dlp` nunca utiliza (`libsqlite3`, `_sqlite3`, `_tkinter`, `_test`, `_ctypes_test`, `_curses`, `audioop`, `_decimal`, `_lsprof`, `_xxsubinterpreters`, `_statistics`, `_zoneinfo`, `termios`, `resource`, `cmath`, `mmap`, `_multiprocessing`, codecs CJK antiguos).
    - **Cero Extracción de `stdlib.zip` y Cero Triplicación de Módulos C (`libpymod_*.so` + Symlinks de 0 Bytes)**: Estructura plana en la raíz de `libpython.zip.so` para que CPython importe los `.pyc` directamente desde `nativeLibraryDir/libpython.zip.so` vía `zipimport`, mientras los módulos C nativos se instalan directamente en `nativeLibraryDir/libpymod_<nombre>.so` y `YtDlpNativeEngine` crea enlaces simbólicos (`Os.symlink`) de 0 bytes en `files/env/python/modules/` sin copiar ni triplicar binarios `.so` en el teléfono.
    - **Eliminación de Librerías FFmpeg No Usadas y Dependencias Reservadas**: Exclusión de `libavdevice.so` y `libffmpegkit_abidetect.so` en el aprovisionamiento nativo de FFmpeg, y desactivación temporal en el APK (conservándolas comentadas para uso futuro) de dependencias de red redundantes (`retrofit`, `moshi`, `logging-interceptor`) junto con el filtrado de recursos `localeFilters` conservando Español e Inglés con todas sus variantes regionales (Latinoamérica `es-r419`, España `es-rES`, EE.UU. `es-rUS`, México, Argentina, Colombia, Chile, Perú, etc., e Inglés en variantes regionales incluyendo `en-rES` / `b+en+ES`).
    - **Eliminación de Duplicación de `yt-dlp`**: Ejecución directa desde `nativeLibraryDir/libytdlp.zip.so` sin duplicar el binario en `assets/bin/` ni copiarlo a `files/bin/yt-dlp` al abrir la app (usando `files/bin/yt-dlp` solo cuando se descarga una actualización OTA).
    - **Optimización Agresiva con R8 Full Mode, Ofuscación en APK Beta, Single DEX y Eliminación de Logs/Trazas (`proguard-rules.pro` & `gradle.properties`)**: Activación de `android.enableR8.fullMode=true`, `multiDexEnabled = false` (Single DEX / compactación de strings en un único `classes.dex`), ofuscación activa en el APK Beta/Release (`-repackageclasses 'a'`, `-flattenpackagehierarchy 'a'`, `-overloadaggressively`, `-mergeinterfacesaggressively`, `-renamesourcefileattribute ''` y omisión de `SourceFile,LineNumberTable`) preservando solo lo delicado (métodos `native` de `NativeAudioEngine`, constructores/campos de entidades Room y constructores del `AndroidManifest`), eliminación de reglas `-keep` amplias con comodín (`*;`) y de `-keep class com.example.model.** { *; }` (permitiendo que R8 elimine al 100% `DebugMonitorActivity` en Beta y métodos muertos de modelos), eliminación automática de logs de depuración (`android.util.Log.v/d/i`) y chequeos `Intrinsics.checkNotNull*`, poda de `@kotlin.Metadata` y poda automática de los ~9,900 iconos no usados de `androidx.compose.material:material-icons-extended`.
    - **Desactivación de Excepciones C++, RTTI y Tablas de Unwind en CMake C++20 y NDK**: Activación de `-Oz -flto -fno-exceptions -fno-rtti -fno-unwind-tables -fno-asynchronous-unwind-tables -fvisibility=hidden -ffunction-sections -fdata-sections -Wl,--gc-sections -Wl,--icf=all -Wl,--exclude-libs,ALL -Wl,-s` y compresión de librerías nativas en el APK (`useLegacyPackaging = true`).
- [x] **Fondo de Pantalla Personalizado de Galería (Imagen WebP / Video Corto), Motor Crossfade Dual-Deck Profesional, Modo Juego en 2do Plano y Transición de Color a 1 Segundo (`v0.2.0-beta-1a`)**:
  - **Fondo de Pantalla de Galería (`AppWallpaperConfig`, `AppWallpaperBackground` & `AppWallpaperSettingsSection`)**: Permite elegir desde la galería del teléfono cualquier imagen (convertida en segundo plano a WebP Lossless en `images/`) o video corto (optimizado sin pista de audio en `videos/`) para mostrarlo como fondo de pantalla en *Tu Biblioteca*, *Biblioteca e Inicio* o *Toda la aplicación*, con controles deslizantes en vivo de **Oscurecimiento / Velo OLED (25%–92%)** y **Desenfoque / Blur (0–25 dp)**.
  - **Crossfade Profesional Dual-Deck Superpuesto (`AudioFadeController.startDualDeckCrossfade` & `AuraAudioPlayer.outgoingExoPlayer`)**: Reemplaza el fundido secuencial de un solo reproductor por una arquitectura de doble reproductor sincronizado (`Deck A + Deck B`) con curva trigonométrica de igual potencia (`sin(t * PI/2)` para la canción entrante y `cos(t * PI/2)` para la canción saliente), logrando que ambas canciones suenen superpuestas durante la transición sin un solo milisegundo de pausa ni caída de volumen.
  - **Transición de Colores de Video Suave a 1 Segundo (`ArtworkColorExtractor.INTERVAL_NORMAL_MS = 1000L` & `tween(1000)`)**: Tanto en *Now Playing* como en el *Mini Reproductor*, los cambios de color extraídos del video se muestrean cada 1000 ms con fundido suave de 1 segundo para evitar cambios bruscos o mareos visuales.
  - **Modo Juego / Ahorro Inteligente de Recursos en Segundo Plano (`AuraApplication.isAppInForegroundFlow` & `isBackgroundGameModeEnabled`)**: Suspende automáticamente en segundo plano el decodificador de video, la captura de texturas, el hilo del visualizador espectral de 28 bandas y recorta cachés gráficas en RAM, manteniendo 100% activos la música y todos los efectos de audio en uso.
- [x] **Carpeta Pública / Personalizada del Usuario y Exportación de Vídeos con Audio Completo en Ajustes > Medios & Almacenamiento**:
  - **Selección de Carpeta sin Restricciones (`UserPublicMediaExporter` & `OpenDocumentTree`)**: Permite al usuario crear o elegir libremente cualquier carpeta de su teléfono con permisos persistentes de lectura/escritura, organizando automáticamente una subcarpeta `Videos/` (y dejando lista la estructura para `Images/` en el futuro).
  - **Visualización de Ruta Exacta (`UserPublicFolderCard`)**: Traduce el identificador SAF a una ruta clara y legible para el usuario (ej. `Almacenamiento interno / Mi Carpeta / Videos`) directamente en **Ajustes > Medios & Almacenamiento**.
  - **Unión Instantánea de Vídeo + Audio en FFmpeg (`FFmpegNativeEngine.mergeVideoCanvasWithTrackAudio`)**: Como el Video Canvas interno se almacena sin audio (`-an`) para no interferir con el ecualizador C++20, al exportar hacia la carpeta pública del usuario se une en segundo plano (`Dispatchers.IO`) el flujo de vídeo con la pista de audio original de la canción (soportando tanto vídeos sincronizados completos con `-c copy` como loops cortos con `-stream_loop -1`), entregando un archivo `.mp4` con sonido completo listo para reproducirse en cualquier galería o reproductor externo.
- [x] **Modo Streaming Híbrido Estilo Spotify (`Explorar`), Búsqueda API Dual (`YT MUSIC` / `YOUTUBE`), Pre-Descarga No Lineal en Caché (50–500 MB • 30 min TTL), Radio Similar y Política de Red para Video Canvas**:
  - **Búsqueda por API Dual + Resolución con `yt-dlp` (`StreamingApiService` & `YtDlpNativeEngine`)**: La búsqueda de canciones y la obtención de pistas similares se ejecutan exclusivamente mediante la API (`InnerTube WEB_REMIX` para YouTube Music e `InnerTube WEB` para YouTube Estándar), etiquetando cada resultado con su indicador **`YT MUSIC`** o **`YOUTUBE`**. Al reproducir (o antes de saltar a la canción anterior/siguiente), consulta a la API y `yt-dlp` toma la pista normalizando enlaces `music.youtube.com` para reproducir tanto temas de YouTube Music como de YouTube.
  - **Pre-Descarga No Lineal Adelantada y Caché Inteligente de 30 Minutos (`StreamingCacheManager`)**: Mientras el usuario escucha en streaming, descarga por adelantado los próximos minutos de la canción mediante bloques `HTTP Range` (no lineal) y almacena tanto el audio como el Video Canvas en caché temporal (`cacheDir/aura_streaming_cache/`). Configurable por el usuario en Ajustes con **50 MB por defecto** y **máximo de 500 MB**, permitiendo regresar a la canción anterior o repetir en bucle al instante. Purga automáticamente los archivos con **más de 30 minutos sin usarse** y aplica desalojo *LRU* (elimina primero las canciones más viejas) cuando se llena el límite.
  - **Política de Video Canvas Exclusiva para Streaming (`StreamingVideoNetworkPolicy`)**: Nueva opción en **Ajustes > Aura Dinámica, Streaming & Modo Juego** para configurar los videos Canvas en streaming en **Videos solo con Wi-Fi**, **Siempre (incluso con datos móviles)** o **Desactivado**, sin tocar ni alterar en absoluto la reproducción de videos locales.
  - **Radio de Canciones Similares, Letras LRCLIB y Descarga Permanente**: Pre-resuelve automáticamente una canción similar antes de finalizar la pista actual, carga sus letras sincronizadas `.LRC` desde `LRCLIB`, desactiva temporalmente el procesamiento C++20 durante el streaming (`NativeAudioProcessor.isStreamingBypassActive = true`) e integra botón de descarga permanente hacia `songs/`, `images/` y `videos/` con `AuraDownloadService`.
  - **Armonización Cromática Online Cada 1s, Indicadores de Carga/Red y Optimización Térmica en Streaming**: Extracción dinámica de color desde carátulas remotas (`https://`) y muestreo cada 1 segundo (`1000 ms` con `tween(1000)`) directamente sobre la textura GPU del video (`BackgroundVideoPlayer`) sin abrir conexiones HTTP duplicadas en `MediaMetadataRetriever`; indicadores de carga y espera de internet directamente en el botón Play/Pausa y en la miniatura tanto en `NowPlaying` como en `MiniPlayer`; y enfriamiento del dispositivo priorizando resolución nativa `InnerTubeClient` (`<300ms`), escalonando la pre-descarga de caché, evitando recrear el decodificador al completarse la caché en segundo plano (`updateCurrentTrackIfSame = false`) y limitando la decodificación de video online a `480p @ 30fps`.
  - **Erradicación de Fuga OEM en `AuraDownloadService` (`ContextImpl.mOuterContext`) y Sub-Menús Modulares en "Aura Dinámica, Streaming & Modo Juego"**: Desvinculación de `ContextImpl.mOuterContext` hacia `applicationContext` al destruir servicios (`AuraDownloadService` y `AuraMediaPlaybackService`) junto con delegación de `getResources()` al contexto global para evitar la retención estática `ResourcesImpl.mAppContext -> ContextImpl -> Service` en ROMs OEM; y reorganización del apartado **"Aura Dinámica, Streaming & Modo Juego"** en Ajustes en **4 sub-apartados independientes a pantalla completa** (*Streaming & Caché Inteligente*, *Aura Dinámica (1s) & Mini Reproductor*, *Modo Juego / Ahorro en 2do Plano* y *Fondo de Pantalla de Galería*).
- [x] **Importador Universal de Playlists de Spotify y YouTube Music / YouTube + Búsqueda y Streaming en SoundCloud (`ExternalPlaylistImporter`, `PlaylistImportCoordinator`, `ImportExternalPlaylistDialog` & `SoundCloudApiClient`)**:
  - **Importador de Playlists Públicas de Spotify y YouTube Music Sin Login ni API Keys (`ExternalPlaylistImporter`)**:
    - Extracción automática de metadatos de playlists públicas de **Spotify** (`open.spotify.com/playlist/{id}`, `spotify.link/...`) mediante parseo de hidratación JSON de `open.spotify.com/embed/playlist/{id}` (`__NEXT_DATA__` / `initial-state`) y respaldo DOM en WebView móvil, obteniendo título, autor, portada de alta resolución y lista completa de canciones con artista, álbum, duración y miniatura.
    - Extracción rápida de playlists de **YouTube Music / YouTube** (`music.youtube.com/playlist?list=...`, `youtube.com/playlist?list=...`) combinando consulta directa a `InnerTube browse` (`VL<playlistId>`) y respaldo en `YtDlpNativeEngine.resolveFlatPlaylist` (`--flat-playlist -J`).
  - **Doble Modo de Guardado Seleccionable por el Usuario (`PlaylistImportSaveMode` & `PlaylistImportCoordinator`)**:
    - **⚡ Modo Streaming Rápido (Instantáneo)**: Descarga y comprime la portada oficial de la Playlist a **WebP Lossless** en `images/`, crea la Playlist en Room Database e inserta todas sus pistas como canciones de Modo Streaming (`isStreamingTrack = true`) listas para reproducirse al instante bajo demanda (resolviendo sus flujos en `AuraAudioPlayer` y `StreamingModeCoordinator` al tocarlas).
    - **📥 Descargar Todo Offline (En 2do plano)**: Crea la Playlist con su portada WebP y descarga todas sus pistas secuencialmente en segundo plano con `AuraDownloadService` (soportando vinculación automática de **Video Canvas en 480p** y **recorte inteligente de silencios**), añadiendo cada canción descargada en `.m4a` a la Playlist.
  - **Acceso desde 3 Puntos Estratégicos**:
    - En **Tu Biblioteca (Pestaña Playlists)** mediante el botón **"Importar"** junto a *"Nueva Lista"* y la tarjeta destacada de importación.
    - En la pantalla **Importar Música (`ImportMusicScreen`)** mediante la tarjeta dedicada *"Importar Playlist de Spotify / YT Music"*.
    - Vía **"Compartir con..." (`IncomingMediaCoordinator`)**: Al compartir un enlace de playlist directamente desde la app de Spotify o YouTube Music hacia Aura Music, abre automáticamente el modal con el análisis de la lista en curso.
  - **Integración de SoundCloud en el Buscador de Streaming (`SoundCloudApiClient` & `StreamingExploreScreen`)**:
    - Hidratación dinámica y en caché del `client_id` público de SoundCloud (`api-v2.soundcloud.com`) desde sus bundles web oficiales, con respaldo por hidratación HTML y `yt-dlp` (`scsearch:`).
    - Integrado simultáneamente en el filtro **Todo (YT Music, YT & SoundCloud)** (intercalando resultados de las 3 plataformas) y en su propio chip dedicado **☁️ Solo SoundCloud**, identificado con la insignia naranja vibrante **`☁️ SOUNDCLOUD` (`#FF5500`)**.
    - Resolución de streams progresivos HTTP (MP3 / Opus) compatibles con la caché inteligente de 30 minutos (`StreamingCacheManager`), extracción cromática de portadas remotas en `ArtworkColorExtractor`, Radio de canciones similares y descarga permanente en 1 toque.
- [x] **Blindaje Definitivo Anti-HTTP 403 en `googlevideo.com` y Cascada Automática de 5 Niveles (`YtDlpNativeEngine`, `ChunkedStreamDownloader`, `StreamingHttpDataSourceConfig`, `OnlineVideoAudioImporter` & `MediaAssetProcessor`)**:
  - **Separación Estricta de Cabeceras por Flujo (`audioHeaders` vs `videoHeaders`)**: Aislamiento de las cabeceras HTTP de cada formato en `YtDlpNativeEngine`, `InnerTubeClient` y `ResolvedMediaInfo` para impedir que el formato de video 480p sobrescriba el `User-Agent` firmado del formato de audio `.m4a`.
  - **Alineación Inteligente por Parámetro `c=` en `StreamingHttpDataSourceConfig` y `ChunkedStreamDownloader`**: Inspección automática del parámetro `c=` (`ANDROID_VR`, `IOS`, `ANDROID_MUSIC`, `ANDROID`, `VISIONOS`, `TVHTML5`, `MWEB`, `WEB`) en cada URL de `googlevideo.com`, asignando el `User-Agent` y `Origin` canónicos de ese cliente y bloqueando la inyección de cookies de `m.youtube.com` en clientes nativos (`ANDROID_VR`/`IOS`).
  - **Reconocimiento Universal de Subdominios de YouTube (`music.youtube.com`, `m.youtube.com`, `www.youtube.com`, `youtu.be`)**: Expresión regular mejorada en `WebStreamExtractor.extractVideoId` para activar siempre la autoreparación en pistas de YouTube Music y YouTube.
  - **Cascada Automática de 5 Niveles de Fallback (Audio, Video Canvas 480p y Pre-Carga de Caché)**:
    1. **Nivel 1**: Normalización y reintento por perfil `c=` en `ChunkedStreamDownloader`.
    2. **Nivel 2**: Resolución alternativa inmediata vía **`InnerTubeClient`** (`ANDROID_VR` -> `VISIONOS` -> `ANDROID_MUSIC` -> `IOS`).
    3. **Nivel 3**: Bypass vía **`InvidiousStreamResolver`**.
    4. **Nivel 4**: Extracción vía **`HeadlessWebViewExtractor`** (`m.youtube.com`).
    5. **Nivel 5**: Descarga directa nativa a archivo mediante **`YtDlpNativeEngine.downloadStreamDirectToFile`** usando el propio transporte TLS/HTTP de Python.


