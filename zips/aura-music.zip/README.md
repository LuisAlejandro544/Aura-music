<div align="center">

# 🌌 Aura Music (`Aura Beta` • Codename: *Nebula*)

### **Tu estudio audiófilo, centro de descargas y experiencia Video Canvas en tu bolsillo.**
**100% libre de anuncios y sin suscripciones.**

[![Versión Beta](https://img.shields.io/badge/Versi%C3%B3n-v0.2.0--beta--1a%20(Nebula)-8B5CF6?style=for-the-badge&logo=android&logoColor=white)](../../releases)
[![Lenguaje Principal](https://img.shields.io/badge/Lenguaje-Kotlin%20%2B%20Jetpack%20Compose-7F52FF?style=for-the-badge&logo=kotlin&logoColor=white)](./READMEAI.md)
[![Motor de Audio](https://img.shields.io/badge/Audio%20DSP-ISO%20C%2B%2B20%20(64--bit)%20%2B%20AAudio-00D2FF?style=for-the-badge&logo=cplusplus&logoColor=white)](./READMEAI.md)
[![Android API](https://img.shields.io/badge/Android-8.0%2B%20(API%2026--36)-3DDC84?style=for-the-badge&logo=android&logoColor=white)](../../releases)
[![Arquitecturas](https://img.shields.io/badge/ABI-arm64--v8a%20%7C%20armeabi--v7a-F59E0B?style=for-the-badge)](../../releases)
[![Privacidad](https://img.shields.io/badge/Anuncios%20y%20Rastreo-0%25%20(100%25%20Offline--First)-10B981?style=for-the-badge)](./LICENSE)

<br/>

[![Descargar Último APK](https://img.shields.io/badge/⬇️%20DESCARGAR%20APK%20OFICIAL%20(RELEASES)-111827?style=for-the-badge&logo=github&logoColor=00D2FF)](../../releases)
[![Documentación Técnica](https://img.shields.io/badge/📖%20ARQUITECTURA%20E%20INGENIERÍA%20(READMEAI)-1F2937?style=for-the-badge&logo=readthedocs&logoColor=A78BFA)](./READMEAI.md)
[![Changelog Beta](https://img.shields.io/badge/🚀%20NOVEDADES%20DE%20LA%20VERSIÓN%20(CHANGELOG)-1F2937?style=for-the-badge&logo=sparkles&logoColor=F472B6)](./chanelog-beta.md)

</div>

---

## 🌟 ¿Por qué elegir Aura Music?

**Aura Music** es un reproductor musical de alta fidelidad para Android diseñado con estética **Dark Luxury Neo-Glass OLED** (100% opaco, sin transparencias borrosas), creado para quienes buscan calidad de sonido de estudio, fondos de video inmersivos y herramientas completas para armar su biblioteca directamente desde el celular:

- 🚫 **Cero Anuncios y Privacidad Estricta**: Sin publicidad, sin telemetría invasiva y sin escaneos ocultos de tus carpetas. Tú eliges exactamente qué música o videos importar.
- 🎛️ **Motor Acústico Nativo en C++20 y Bit-Perfect**: Procesamiento en coma flotante de 64 bits con **Ecualizador de 10 bandas**, **Audio 8D / 16D Multi-Órbita**, **Clarificador de Voces HD**, **Reverb sin bloqueos**, **Normalizador EBU R128** y **Modo Bit-Perfect con Google AAudio**.
- 🎬 **Video Canvas & Modo Cinemático**: Reproduce videos sincronizados o bucles continuos de fondo (con colores reactivos en tiempo real y 0ms de retraso al adelantar la canción).
- 📥 **Descargas y Conversión Todo en Uno**: Descarga canciones y videos de fondo directamente desde enlaces web (**YouTube, TikTok y más**) a máxima velocidad, convierte cualquier video de tu galería en música en 1 segundo y une canciones con el **Creador de Mixtapes**.
- 🔄 **Siempre al Día (Actualizaciones OTA Integradas)**: Incluye actualizador automático tanto para nuevas versiones del APK como para el motor interno de extracción (`yt-dlp`), todo verificado con seguridad criptográfica `SHA-256`.

---

## 🎧 Especificaciones Audiófilas y Formatos Soportados

Aura Music combina la versatilidad de **Jetpack Media3 (ExoPlayer)** con un puente directo a **Google AAudio (`libaaudio.so`)**, **FFmpeg nativo** y un procesador **DSP en ISO C++20**:

| Categoría Técnica | Especificación en Aura Music |
| :--- | :--- |
| **Precisión de Procesamiento DSP** | Coma flotante de doble precisión (**64-bit Float**) en filtros Biquad IIR con limitador suave anti-clipping (`std::tanh`) y *Buffer Flushing* atómico (cero chasquidos al saltar o pausar). |
| **Salida de Audio & Latencia** | **Google AAudio (`AAUDIO_PERFORMANCE_MODE_LOW_LATENCY`)** con soporte para **Modo Bit-Perfect 1:1** (Bypass directo sin alteración de fase/ganancia) y modo exclusivo para DACs USB / Audífonos Hi-Res. |
| **Resoluciones de Salida** | *Nativo 1:1 (Sin Resampling)* • *Hi-Res 96 kHz / 24-bit* • *Ultra Hi-Res 192 kHz / 32-bit Float*. |
| **Formatos Estándar y Sin Pérdida** | `FLAC`, `WAV` (PCM 16/24/32-bit), `ALAC` (`.alac`), `AIFF` (`.aiff`), `M4A` (AAC), `MP3`, `OGG` (Vorbis), `OPUS`. |
| **Formatos Audiófilos & Especiales** | **DSD** (`.dsf`, `.dff` — DSD64/128), **Monkey's Audio** (`.ape`), **WavPack** (`.wv`), **Musepack** (`.mpc`). |
| **Formatos Retro / Chiptune** | Decodificación nativa de módulos Tracker: `.mod`, `.xm`, `.it`, `.s3m`. |
| **Procesamiento de Portadas** | Compresión automática en segundo plano a **WebP Lossless** (sin pérdida de calidad) + **Arte Procedural Vectorial** para pistas sin portada. |

---

## 🚀 Funciones Principales en Detalle

Haz clic en cada categoría para desplegar todas sus herramientas y características técnicas:

<details open>
<summary><b>🎛️ 1. Estudio Acústico DSP (10 Bandas, Audio 8D/16D, Voces HD, Reverb y DJ Automix)</b></summary>
<br/>

Todo el panel de efectos se despliega al instante en una hoja modal desde el **Mini Reproductor** o desde **Now Playing**, sin interrumpir tu navegación:

- **Ecualizador Paramétrico de 10 Bandas ISO + Bass Boost (60 Hz)**:
  - Bandas identificadas con nombres claros: `31 Hz (Subgraves)`, `62 Hz (Bajos)`, `125 Hz (Graves)`, `250 Hz (Cuerpo)`, `500 Hz (Medios Bajos)`, `1 kHz (Voces)`, `2 kHz (Claridad)`, `4 kHz (Presencia)`, `8 kHz (Brillo)` y `16 kHz (Aire / Agudos)`.
  - Rango de `-15 dB` a `+15 dB`, perfiles predefinidos (*Rock, Pop, Electrónica, Jazz, Acústico, Bass Boost, Plano*) y selector de alcance: aplícalo **🌐 Para todas las canciones** o **🎵 Solo para la canción actual**.
- **Clarificador de Voces HD (Procesamiento Mid-Side)**:
  - Separa el canal vocal central (*Mid*) del acompañamiento lateral (*Side*), atenúa la turbidez en `180 Hz` y realza la presencia y dicción de la voz en `2.8 kHz` y `5.5 kHz`.
- **Audio Espacial 8D y 16D Multi-Órbita Binaural**:
  - **Modo 8D Clásico**: Rotación de 360° alrededor de tu cabeza con filtro de sombra acústica craneal (*Head Shadow*).
  - **Modo 16D Multi-Órbita**: Divide la canción en dos capas contra-rotatorias independientes (los bajos se mantienen estables en una órbita interna mientras las voces y agudos trazan una figura-8 con micro-retardo Haas).
- **Suite Reverb 100% C++20 (Cero Silencios)**:
  - Simulación acústica de espacios reales (*Estudio, Sala Mediana, Club En Vivo, Gran Hall, Catedral, Eco Espacial*) con control libre de tamaño de sala, decaimiento y mezcla.
- **Velocidad y Tono Independientes (`0.50x` a `2.00x`) + Repetidor A-B**:
  - Modula la velocidad de la música y el tono de la voz por separado (ideal para *Slowed + Reverb*, *Nightcore* o practicar instrumentos) con botones rápidos (`0.8x`, `1.0x`, `1.25x`, `1.5x`, `2.0x`) y barra compacta de **Bucle A-B** con ajuste fino de `±1s`.
- **Normalizador de Volumen Inteligente (EBU R128 / Nivel Spotify)**:
  - Iguala automáticamente el volumen entre canciones suaves y fuertes con 3 niveles: *Sutil (-18 LUFS)*, *Estándar (-14 LUFS)* y *Alto (-11 LUFS)*.
- **Crossfade Profesional Dual-Deck & Automix Inteligente DJ con Curva en X**:
  - Motor de **doble reproductor sincronizado (`Deck A + Deck B`)** con curva trigonométrica de igual potencia (*Equal-Power S-Curve: `sin/cos`*): cuando una canción baja de volumen, la siguiente empieza a sonar **exactamente al mismo tiempo** sin un solo milisegundo de pausa, atenuando subgraves (`<120 Hz`) de la pista saliente para evitar choques de bajos.
- **Temporizador de Apagado con Fade-Out**:
  - Apaga la música automáticamente tras el tiempo elegido disminuyendo suavemente el volumen durante los últimos 10 segundos.

</details>

<details>
<summary><b>🎧 2. Zona Exclusiva para Auriculares (Crossfeed, Balance L/R, Seguridad y Gestos)</b></summary>
<br/>

- **Filtro Crossfeed Acústico (Algoritmo Bauer / Chu Moy)**:
  - Reduce la fatiga auditiva en sesiones largas mezclando sutilmente ambos canales con retardo interaural, logrando que los audífonos suenen naturales como monitores de estudio frente a ti. **Se activa automáticamente solo cuando conectas auriculares** (cable 3.5mm, USB-C o Bluetooth) y se apaga al usar el altavoz del móvil.
- **Balance Estéreo Fino (Izquierda / Derecha L/R)**:
  - Ajusta el volumen de cada oído por separado en tiempo real desde *Now Playing* o la hoja de efectos, con botón rápido para centrar a `0%`.
- **Protección contra Desconexiones (*Becoming Noisy Guard*) y Fade-In**:
  - Pausa la reproducción en el acto si se desconecta el cable o se apagan tus audífonos Bluetooth para que jamás suene por accidente en público, y reanuda el sonido con una subida progresiva de 1 segundo para cuidar tus oídos.
- **Memoria de Volumen Independiente y Mapeo de Botones**:
  - Guarda un nivel de volumen distinto para tus audífonos y otro para el altavoz, y personaliza qué acción ejecutan 1, 2, 3 pulsaciones o mantener presionado el botón de tus auriculares.

</details>

<details>
<summary><b>🎬 3. Video Canvas Dinámico, Modo Cinemático y Armonización Cromática</b></summary>
<br/>

- **2 Diseños de Reproductor + Modo Automático**:
  - **Modo Clásico**: Carátula cuadrada 1:1 en alta nitidez, visualizador espectral de 28 bandas y controles tradicionales.
  - **Modo Cinemático Canvas (Estilo Spotify)**: Despeja más del 70% de la pantalla para el video de fondo, mostrando una viñeta luminosa adaptada en tiempo real a los colores del video, minicarátula de 54dp, frase de Karaoke flotante y controles inferiores con selector circular clásico ("bolita").
  - **Modo Automático Inteligente**: Cambia solo al diseño Cinemático cuando la canción tiene video y vuelve al Clásico cuando solo tiene portada.
- **4 Modos de Encuadre para Videos Horizontales (16:9) y Verticales (9:16)**:
  - Elige en cualquier momento entre *Fondo Completo (Rellenar / Recortar)*, *Fondo Completo (Adaptado Horizontal sin recortar rostros)*, *Lienzo en Carátula (1:1)* o *Solo Carátula*.
- **Ingeniería FFmpeg en tus Videos de Fondo**:
  - **Bucles Infinitos sin Cortes**: En videos cortos (≤20s), elige entre fundido continuo (*Seamless Crossfade*) o **Efecto Boomerang / Ping-Pong** (ida y vuelta sin saltos).
  - **Saltos Instantáneos (0ms) y Ahorro de Espacio (hasta -85%)**: En videos largos sincronizados (>20s), reestructura los fotogramas clave a 1 segundo (GOP corto a 30fps) y elimina la pista de audio redundante (`-an`) del archivo de video para que adelantar o cambiar de canción sea instantáneo y sin pantallas negras.
- **🖼️ Fondo de Pantalla Personalizado de Galería (Imagen WebP o Video Corto)**:
  - Elige una **foto o un video corto de tu galería** para mostrarlo como fondo de pantalla mientras navegas por **Tu Biblioteca**, **Inicio** o **toda la aplicación**, con controles en vivo de **Oscurecimiento / Velo OLED (25%–92%)** y **Desenfoque / Blur (0–25 dp)** en *Ajustes > Aura Dinámica, Video & Modo Juego*.
- **Armonización Cromática Suave a 1 Segundo (Cero Mareos Visuales)**:
  - Tanto en el reproductor completo como en el **Mini Reproductor**, los colores del video se muestrean cada **1 segundo (1000 ms)** con un fundido orgánico de **1000 ms**, evitando parpadeos bruscos.
- **🎮 Modo Juego / Ahorro Inteligente en Segundo Plano**:
  - Al minimizar la app para jugar, **Aura Music libera automáticamente todo lo que no se está viendo** (apaga el decodificador de video en GPU, detiene la captura de texturas, suspende el hilo del visualizador espectral de 28 bandas y recorta cachés gráficas en RAM), mientras **mantiene 100% activos la música y únicamente los efectos de audio que tengas encendidos** (EQ, 8D/16D, Reverb, A-B Loop o Crossfade Dual-Deck). Configurable en *Ajustes > Aura Dinámica, Video & Modo Juego*.

</details>

<details>
<summary><b>📥 4. Descargas Web (YouTube/TikTok), Video a Música, Mixtapes y "Compartir con..."</b></summary>
<br/>

- **Descargador Integrado de Enlaces Web en Segundo Plano (`AuraDownloadService`)**:
  - Pega enlaces de **YouTube, TikTok o la web** para descargar la canción con su portada oficial en WebP y su **Video Canvas en 480p** vinculado automáticamente.
  - **Arquitectura Resiliente Multi-Motor con Cascada Anti-HTTP 403 de 5 Niveles**: Separa estrictamente las cabeceras HTTP por flujo (`audioHeaders` vs `videoHeaders`) alineando el `User-Agent` y `Origin` al parámetro firmado `c=` de `googlevideo.com`, e integra una **cascada automática de 5 niveles de respaldo** (**1.** Reparación de cabeceras por perfil `c=` → **2.** **`InnerTube Multi-Cliente`** `ANDROID_VR`/`VISIONOS`/`ANDROID_MUSIC`/`IOS` en `<300ms` → **3.** **`Bypass Invidious`** → **4.** **`WebView Móvil`** → **5.** **`Descarga directa nativa con yt-dlp CLI`**).
  - **Acelerador HTTP Range Multi-Bloque**: Rompe el límite de velocidad de red descargando entre **10 MB/s y 40 MB/s**, continuando en segundo plano con notificación en vivo aunque salgas de la aplicación.
- **Importador Universal de Playlists de Spotify y YouTube Music / YouTube (`ExternalPlaylistImporter`)**:
  - Importa cualquier Playlist pública de **Spotify** o **YouTube Music / YouTube** pegando su enlace (desde **Tu Biblioteca > Playlists**, **Importar Música** o usando **Compartir con...** directamente desde la app de Spotify o YouTube Music), **sin necesidad de iniciar sesión ni usar claves API**.
  - Extrae título, autor, portada oficial (convertida automáticamente a **WebP sin pérdida** en `images/`) y la lista completa de canciones, permitiéndote elegir cómo guardarla:
    1. ⚡ **Modo Streaming Rápido (Instantáneo)**: Crea la Playlist en segundos en tu biblioteca lista para escuchar bajo demanda sin ocupar almacenamiento.
    2. 📥 **Descargar Todo Offline (En 2do plano)**: Crea la Playlist y descarga automáticamente todas sus canciones en alta fidelidad (con portada WebP y Video Canvas opcional) mediante `AuraDownloadService`.
- **Conversor "Video a Música" 3 en 1 (En 1 Segundo)**:
  - Selecciona cualquier video de tu galería y extrae el audio directo a `.m4a` sin perder calidad (*Direct Stream Copy*), generando su portada WebP y vinculando el video de fondo al instante.
- **Puente Inteligente "Abrir con..." y "Compartir con..."**:
  - Comparte archivos de audio, videos, enlaces de canciones o **Playlists completas de Spotify / YouTube Music** directamente desde **Spotify, YouTube Music, SnapTube, navegadores, Telegram, WhatsApp o gestores de archivos** hacia Aura Music: la app detecta qué es, despliega el importador o guarda el medio en tu biblioteca permanente y lo reproduce de inmediato.
- **Creador de Mixtapes (Fusión Continua con Capítulos Reactivos)**:
  - Une varias canciones de una Playlist en un solo archivo continuo `.m4a` con transiciones suaves de 3s, 5s, 8s o 10s. Mientras suena el Mixtape, Aura Music cambia automáticamente el título, la portada, el Video Canvas y la letra sincronizada en cada capítulo.
- **Recorte Automático de Silencios (`AudioSilenceTrimmer`)**:
  - Interruptor disponible antes de cada importación o descarga para detectar y recortar los silencios al inicio y al final de la pista (`-42 dB` RMS).

</details>

<details>
<summary><b>🎤 5. Karaoke Sincronizado (.LRC / .TXT), Personalización OLED y Control de Almacenamiento</b></summary>
<br/>

- **Letras Estilo Karaoke con Descarga Automática (`LRCLIB`)**:
  - Descarga letras sincronizadas automáticamente sin registro, o usa el **Buscador Interactivo** que destaca la versión `⭐ OFICIAL / RECOMENDADA` en primer lugar y te permite comparar variantes comunitarias o importar tus propios archivos `.lrc` y `.txt`.
  - **Modo Karaoke a Pantalla Completa**: Vista inmersiva estilo *Apple Music Sing / Spotify* con letra grande iluminada en neón, auto-scroll y salto de tiempo al tocar cualquier verso.
- **Temas OLED, Material You, Collages, 2 Widgets Interactivos y Android Auto**:
  - 5 paletas de acento neón (*Material You dinámico, Nebula Violet, Cyber Mint, Sunset Ember, Ocean Abyss*) y Playlists con portada personalizada o collage automático de 1 a 4 fotos.
  - **2 Widgets Interactivos con Color Dinámico de la Imagen y Reanudación en Segundo Plano**:
    - **Widget 1 (Reproductor Adaptativo)**: Reacciona automáticamente a los colores de la carátula de la canción actual, permite reanudar la música que estabas escuchando directamente en segundo plano (incluso tras cerrar la app), incluye botón de **Favorito ❤️** y **se adapta al estirarlo** en tu pantalla de inicio (*Compacto 4x1*, *Mediano 4x2 con barra de progreso y tiempos* y *Expandido 4x3 de estudio*).
    - **Widget 2 Independiente (Top 4 Canciones & 4 Playlists)**: Un segundo widget de buen tamaño (cuadrícula 2x2) que muestra tus **4 canciones más escuchadas** o tus **4 Playlists principales** (con su portada o collage dinámico) para reproducirlas con un solo toque, todo 100% configurable con vista previa en vivo desde el nuevo apartado **Ajustes > Widget**.
  - Soporte integrado para consolas de vehículos compatibles con **Android Auto**.
- **Transparencia Total de Almacenamiento y Carpeta Pública de Vídeos**:
  - En **Ajustes > Medios & Almacenamiento** puedes inspeccionar cada portada WebP y cada Video Canvas MP4 guardado, ver cuántos KB o MB ocupa y borrar individualmente los que no necesites para liberar espacio al instante.
  - **Carpeta Pública de Usuario (Sin Restricciones)**: Crea o selecciona libremente cualquier carpeta de tu teléfono (`OpenDocumentTree`), visualiza la ruta exacta donde se guardan tus archivos (`.../Videos`) y exporta cualquier vídeo descargado en `.mp4` **con su pista de audio original completa incluida** mediante fusión instantánea en FFmpeg para verlo en tu Galería o compartirlo fuera de la app.

</details>

<details>
<summary><b>🌐 6. Modo Streaming Híbrido Tri-Plataforma (`YT Music`, `YouTube` & `SoundCloud`), Importador de Playlists, Caché No Lineal (50–500 MB • 30 min) y Radio Similar</b></summary>
<br/>

- **Buscador Tri-Plataforma (`YT MUSIC` + `YOUTUBE` + `SOUNDCLOUD`) + Reproducción Híbrida**:
  - Nueva pestaña **Explorar** en la barra inferior: busca canciones, remixes, electrónica, phonk y sets de DJ al instante combinando resultados de **YouTube Music (`🎵 YT MUSIC`)**, **YouTube (`▶️ YOUTUBE`)** y **SoundCloud (`☁️ SOUNDCLOUD`)**, tanto de forma unificada en el filtro **Todo** como mediante el filtro dedicado **☁️ Solo SoundCloud**.
  - **Motor SoundCloud Integrado (`SoundCloudApiClient`)**: Hidrata dinámicamente el `client_id` público de SoundCloud (`api-v2.soundcloud.com`) sin requerir claves ni cuentas, resolviendo flujos progresivos directos en alta fidelidad (MP3 / Opus) con carátulas HD (`500x500`) y respaldo automático en `yt-dlp`.
  - Cuando eliges una canción (o antes de pasar a la canción anterior o siguiente), la app consulta la API y resuelve el flujo de reproducción con letras sincronizadas automáticas desde **LRCLIB**.
- **Pre-Descarga No Lineal Adelantada (Read-Ahead Buffer) & Caché Inteligente de 30 Minutos (`StreamingCacheManager`)**:
  - Mientras escuchas una canción en streaming, Aura Music **pre-descarga por adelantado los siguientes minutos** de la canción (igual que hace YouTube) en segundo plano mediante bloques `HTTP Range`.
  - **Caché para Música y Videos de Fondo (50 MB por defecto hasta 500 MB)**: Configurable por el usuario en **Ajustes > Aura Dinámica, Streaming & Modo Juego**. Permite volver a la canción anterior o repetirla en bucle de forma instantánea sin gastar datos. Los archivos en caché se eliminan automáticamente tras **30 minutos sin usarse**, o eliminando primero las canciones más antiguas (*LRU*) si se llena el límite de hasta 500 MB.
- **Política de Red Exclusiva para Video Canvas en Streaming**:
  - Nueva opción en Ajustes para elegir cómo se comportan los videos de fondo en streaming: **Solo con Wi-Fi**, **Siempre (incluso con datos móviles)** o **Desactivado** (afecta únicamente al streaming sin alterar jamás tus videos locales).
- **Radio Automática de Canciones Similares y Descarga Permanente en 1 Toque**:
  - Antes de que finalice la pista en reproducción (ya sea de YouTube Music, YouTube o SoundCloud), la API busca automáticamente una canción similar y la prepara para ofrecer reproducción continua infinita. Además, puedes pulsar el botón **Descargar** en cualquier resultado o dentro del reproductor para guardarla permanentemente en tu biblioteca offline (durante la reproducción en streaming, los efectos DSP C++20 permanecen en bypass directo, mientras las 28 bandas del visualizador reaccionan en tiempo real).
- **Color Reactivo Cada 1 Segundo, Indicadores de Red y Enfriamiento Inteligente en Streaming**:
  - El reproductor online adapta sus colores dinámicamente cada **1 segundo (1000 ms)** tanto desde las portadas de **YouTube / YT Music / SoundCloud** como desde el video en reproducción.
  - Muestra indicadores claros de carga o espera de internet directamente en el **botón Play/Pausa y en la miniatura** (tanto en el reproductor grande como en el Mini Reproductor), y optimiza el uso de CPU/GPU para mantener el teléfono fresco y ahorrar batería mientras escuchas música online con video.

</details>

---

## 📲 Descarga e Instalación (Guía de APKs)

En la sección de [**Releases Oficiales**](../../releases) encontrarás **3 variantes del instalador APK** optimizadas exclusivamente para dispositivos móviles. Elige la indicada para tu teléfono:

| Archivo APK | Arquitectura | ¿Para qué teléfonos sirve? | Recomendación |
| :--- | :---: | :--- | :--- |
| **`arm64-v8a`** | **ARM 64-bits** | Casi todos los teléfonos Android modernos (fabricados desde 2018 hasta hoy). | ⭐ **Recomendado** (Más ligero, rápido y eficiente en batería) |
| **`armeabi-v7a`** | **ARM 32-bits** | Teléfonos Android antiguos, básicos o con sistemas de 32 bits. | Úsalo solo si el `arm64-v8a` no se instala en tu celular |
| **`universal`** | **32 + 64 bits** | Compatible con **absolutamente cualquier teléfono Android**. | Ideal si no sabes cuál elegir, para compartir con amigos o tiendas como **Uptodown** |

### Pasos rápidos para instalar y actualizar:
1. Ve a [**Releases**](../../releases) y descarga el archivo `.apk` (preferiblemente **`arm64-v8a`**).
2. Ábrelo desde las descargas de tu navegador o gestor de archivos y autoriza la instalación si Android te lo solicita.
3. **Actualizaciones Automáticas sin perder tu música**: Para futuras versiones, puedes buscar, descargar y verificar actualizaciones directamente desde dentro de la app entrando a **Ajustes > Motores Nativos & Diagnóstico**. Todas tus canciones, portadas, videos y playlists guardadas en `Android/data/com.auramusic.beta/files/` se conservarán intactas.

---

## 🛠️ Stack Tecnológico y Documentación de Ingeniería

Aura Music está construida siguiendo principios de **Clean Architecture + MVVM** con desarrollo modular estricto:

- **Interfaz y Arquitectura**: `Kotlin`, `Jetpack Compose (Material 3)`, `Coroutines & StateFlow`, `Room Database`, `Storage Access Framework (SAF)`.
- **Audio y Multimedia**: `Jetpack Media3 (ExoPlayer & MediaSessionService)`, `Google AAudio (NDK)`, `ISO C++20 DSP (CMake)`, `FFmpeg Nativo`, `CPython 3.11 + QuickJS + yt-dlp OTA`.

> 📄 **¿Quieres revisar la arquitectura interna, el árbol de módulos o los detalles de compilación?**  
> Consulta los documentos técnicos del repositorio:
> - [**`READMEAI.md`**](./READMEAI.md) — Documentación técnica exhaustiva de extremo a extremo.
> - [**`STRUCTURE.md`**](./STRUCTURE.md) — Árbol de directorios, coordinadores MVVM y blindaje de seguridad.
> - [**`ROADMAP.md`**](./ROADMAP.md) — Historial de fases de ingeniería completadas.
> - [**`chanelog-beta.md`**](./chanelog-beta.md) — Notas de lanzamiento detalladas de `Aura Beta (Nebula)`.

## 👨‍💻 Detrás del Proyecto (Creador & Contribuidores)

- 🌟 **Creador, Fundador & Propietario del Proyecto**: [**Luis Alejandro Sosa Camacho (`@LuisAlejandro544`)**](https://github.com/LuisAlejandro544)
- 🤝 **Contribuidor Oficial**: [**`@thelandy03-boop`**](https://github.com/thelandy03-boop)

*(Puedes consultar sus perfiles directamente dentro de la app entrando a **Ajustes > Detrás del Proyecto**; las fotos de perfil de GitHub se descargan una única vez y se guardan permanentemente en formato WebP sin pérdida para funcionar incluso sin internet).*

---

## ⚖️ Licencia y Derechos de Autor

**Copyright © 2026 Luis Alejandro Sosa Camacho. Todos los derechos reservados.**

Este proyecto se publica bajo una **Licencia Propietaria de Código Visible (*Source-Available — Viewing Only*)**.  
**Luis Alejandro Sosa Camacho** es el único propietario y titular exclusivo de los derechos del proyecto, otorgando reconocimiento y crédito oficial a los colaboradores autorizados. El código fuente se encuentra disponible en este repositorio **únicamente para su visualización, lectura y consulta**. **Queda estrictamente prohibida** la copia, modificación por terceros no autorizados, compilación externa, creación de obras derivadas, redistribución o uso comercial del código fuente o de sus binarios sin la autorización previa y por escrito del autor.

Consulta el archivo [**`LICENSE`**](./LICENSE) para leer los términos legales completos.
